## Constants

- **BACKEND = `mne`** — MNE-Python is the computation backend.
- **METHOD = `morlet`** — Alternatives: `multitaper`, `stockwell`.
- **FREQS = `np.arange(2, 40, 1)`** unless DATASET_BRIEF specifies bands explicitly.
- **N_CYCLES = `freqs / 2`** — Standard adaptive cycle count (Cohen 2014). Override: `— n_cycles: 7` for fixed.
- **DECIM = `4`** — Temporal decimation to reduce file size. Override: `— decim: 2`.
- **BASELINE = `(-0.5, -0.1)`, mode = `logratio`** — Prefer `logratio` or `db` over `percent` (Grandchamp & Delorme 2011). Override: `— baseline_mode: zscore`.
- **OUTPUT_DIR = `tfr-stage/`** — Create if missing.
- **OUTPUT_FORMAT = `tfr-stage/<sub>/<sub>-<cond>-tfr.h5`** — HDF5 (fif does not handle 4-D TFR well).
- **ITC_OUTPUT = `tfr-stage/<sub>/<sub>-<cond>-itc.h5`** — Inter-trial coherence, saved separately.

> Override: `/eeg-tfr projects/my-study — method: multitaper — bands: theta,alpha — baseline_mode: db`

## Phase A — Parameter Resolution

1. Read `DATASET_BRIEF.md` for:
   - Epoch time window (needed to check edge artifact margin).
   - Frequency bands of interest (e.g., theta 4–8 Hz, alpha 8–13 Hz, beta 13–30 Hz).
   - Sampling rate after decimation during epoching.
2. Read `ANALYSIS_PLAN.md` claim table for TFR-specific claims:
   - Extract `freq_band`, `time_window`, `baseline` per claim.
   - Ensure requested frequencies fall within `FREQS`.
3. Resolve `n_cycles`:
   - **Adaptive** (default): `n_cycles = freqs / 2`. This gives ~3 cycles at 6 Hz (good temporal resolution) and ~20 cycles at 40 Hz (good frequency resolution).
   - **Fixed**: use when comparing across frequencies at matched temporal resolution. Typical: 5–7 cycles.
   - **Logarithmic**: `n_cycles = np.logspace(np.log10(3), np.log10(12), len(freqs))` for compromise.

### Report wavelets by FWHM, not just `n_cycles` (Cohen 2019)

`n_cycles` is the MNE knob, but it is **not** the most interpretable or reproducible way to *describe* a wavelet. Cohen (2019) recommends reporting the **full-width at half-maximum (FWHM)** of the wavelet's Gaussian in **time (ms)** and its dual in **frequency (Hz)** — these are directly readable as "what temporal/spectral smoothing did you apply" and don't depend on the reader re-deriving `sigma_t`. Convert and report both:

```
sigma_t  = n_cycles / (2 * np.pi * f)        # Gaussian std (s)
fwhm_t   = sigma_t * 2 * np.sqrt(2*np.log(2))  # = sigma_t * 2.355  → time FWHM (s)
fwhm_f   = (2 * np.sqrt(2*np.log(2))) / (2 * np.pi * sigma_t)  # frequency FWHM (Hz)
```

So an adaptive `n_cycles = f/2` gives a **constant** time-FWHM of `2.355 / (4*pi) ≈ 187 ms` at every frequency (a useful sanity check). When you build wavelets directly, Cohen's FWHM-Gaussian is `exp(-4*ln(2) * t**2 / fwhm_t**2)`. **COBIDAS:** report the FWHM-time at your lowest and highest frequency, not only `n_cycles`. Cite: Cohen, M. X. (2019). A better way to define and describe Morlet wavelets for time-frequency analysis. *NeuroImage*, 199, 81–86.

### Choosing `n_cycles` — the time/frequency tradeoff (worked numbers)

MNE has **no default** `n_cycles`; it is a first-class scientific choice, not a hidden knob. The Morlet wavelet is a Gaussian-tapered complex sine whose temporal Gaussian std is:

```
sigma_t = n_cycles / (2 * pi * f)        # seconds (Gaussian std)
sigma_f = f / n_cycles                   # Hz (amplitude-envelope std; sigma_t*sigma_f = 1/(2*pi))
```

The **characteristic cycle duration** is `n_cycles / f` seconds; it shrinks with frequency for fixed `n_cycles`. This is not MNE's full sampled wavelet support, which extends to approximately ±5 Gaussian standard deviations (see the padding rule below). Worked table for fixed `n_cycles = 3`:

| f (Hz) | cycle duration `n_cycles/f` (s) | sigma_t (ms) | sigma_f (Hz) |
|---|---|---|---|
| 1  | 3.00 | 477 | 0.33 |
| 2  | 1.50 | 239 | 0.67 |
| 4  | 0.75 | 119 | 1.33 |
| 10 | 0.30 | 48  | 3.33 |
| 30 | 0.10 | 16  | 10.00 |

Reading the table: a small fixed `n_cycles` (e.g. 3) buys sharp **temporal** localization (good for transient ERD/ERS onsets) at the cost of poor **frequency** resolution; raising it (e.g. 7) reverses the trade. The AEA default `n_cycles = freqs / 2` gives constant absolute widths: `sigma_t = 1/(4*pi)` seconds and `sigma_f = 2` Hz at every frequency. A fixed cycle count instead gives frequency-dependent temporal smoothing and constant relative frequency resolution. Choose the cycle schedule according to the temporal and frequency resolution required by the hypothesis.

4. **Check the finite-wavelet edge margin**:
   - MNE samples each Morlet wavelet to approximately ±`5*sigma_t`, so `half_support[f] ≈ 5*n_cycles[f]/(2*pi*f)` seconds, rounded down to the included sample. Exact sampled half-support is `(len(wavelet)-1)/(2*sfreq)`. This is a full finite-kernel padding bound, not a separately defined analytical cone-of-influence threshold.
   - **Required padding rule**: extend the input epoch beyond both sides of the reporting window by the **maximum sampled half-support across frequencies**. For 3 cycles at 2 Hz this is approximately `15/(4*pi) = 1.194 s` per side. For the released `n_cycles=f/2`, it is approximately `5/(4*pi) = 0.398 s` at every frequency; the lowest frequency is not uniquely widest.
   - **Crop after computing.** If the convolution requires samples outside the epoch, MNE uses zeros there, so the resulting edge coefficients depend on padding. Compute on the wide epoch and then crop to the reporting window.
   - **Validation warning**: record a warning in `TFR_SUMMARY.md` if any requested baseline or effect window enters that frequency's sampled half-support from either epoch edge. Apply the maximum margin when retaining a common time window across frequencies.
   - If padding is insufficient, record the required margin and obtain wider input epochs or a user-approved change to the analysis window/cycle schedule. Raising `f_min` reduces the maximum support only if the resolved `n_cycles/f` decreases; it does not help with the released `n_cycles=f/2` schedule.
5. Resolve baseline window and mode:
   - `logratio` (default): `log10(power / baseline_mean)` — dimensionless, symmetric around zero. **Preferred** (Grandchamp & Delorme 2011).
   - `db`: `10 * log10(power / baseline_mean)`, in dB. Apply MNE `logratio`, then multiply by 10; `db` is not a valid MNE baseline mode.
   - `zscore`: `(power - baseline_mean) / baseline_std` — useful when absolute power differences matter.
   - `percent`: `(power - baseline_mean) / baseline_mean * 100` in percent. MNE returns the fractional change for `mode="percent"`; multiply it by 100 before labeling the output %. **Avoid**: asymmetric, inflates increases relative to decreases (Grandchamp & Delorme 2011).
   - `mean`: subtract baseline mean — removes absolute power but retains scale differences across frequencies.
   - Baseline window must fall entirely within the pre-stimulus period. Verify against epoch `tmin`.

   **Caveat — divisive (dB/logratio) baseline is NOT a neutral units choice (Gyurkovics et al. 2021).** The skill's default endorsement of logratio/dB is correct for the *asymmetry* problem but hides a modeling assumption: dividing by baseline power assumes a **multiplicative** relationship between the oscillation and the aperiodic (1/f) background. Empirically, within-participant 1/f power and narrowband (e.g. alpha) power are **not** positively correlated, which supports an **additive** signal+background model instead. Two consequences to encode: (1) a baseline-period shift in the aperiodic **exponent or offset** masquerades as a narrowband change after dB normalization; (2) a condition difference in 1/f produces a **spurious "oscillatory" TFR effect**. Mitigations: parameterize and remove the aperiodic component (specparam / IRASA, see `eeg-spectral`) before or alongside the TFR, or use an **additive (subtraction) baseline** and report the 1/f exponent/offset as a covariate. Cite: Gyurkovics, M., Clements, G. M., Low, K. A., Fabiani, M., & Gratton, G. (2021). The impact of 1/f activity and baseline correction on the results and interpretation of time-frequency analyses of EEG/MEG data. *NeuroImage*, 237, 118192.

Write `tfr-stage/TFR_PARAMS.json` summarizing all resolved parameters before computation.

## Phase B — Backend Resolution

```
1. Read ENVIRONMENT.json
2. Verify MNE-Python is available → generate MNE-Python code
3. Else → ERROR: MNE-Python required
```

Write `tfr-stage/BACKEND_RESOLUTION.md`.

### Method selection — the Heisenberg tradeoff (decision table)

All TFR methods sit on the time-frequency uncertainty curve; pick by whether the question is about *transient timing* or *precise frequency content*.

| Method | Freq resolution | Time resolution | Effective freq res | Best for | MNE call |
|---|---|---|---|---|---|
| **Morlet** (default) | constant absolute for `n_cycles=f/2`; relative for fixed cycles | constant for `n_cycles=f/2`; scales with f for fixed cycles | `≈ f / n_cycles` (Hz) | general ERSP/ITC, broadband | `tfr_morlet` / `tfr_array_morlet` |
| **Multitaper** | constant *absolute*, tunable | fixed by window | set by `time_bandwidth`/window | narrowband, low-variance power | `tfr_multitaper(..., time_bandwidth=4.0)` |
| **Stockwell (S-transform)** | freq-dependent (auto) | freq-dependent (auto) | automatic | broadband, no n_cycles to tune | `tfr_stockwell(fmin, fmax)` |
| **STFT (fixed window)** | constant *absolute* | constant | `≈ Fs / n_window_points` (Hz) | when one freq res across band is desired | `scipy.signal.spectrogram` / `mne.time_frequency.stft` |
| **Hilbert on narrow bands** | low (set by filter band) | **highest** | filter passband width | transient band-power envelopes, single-trial timing | `Epochs.filter(...).apply_hilbert(envelope=True)` |
| **Superlets** | high *and* time-localized (adaptive order) | high | beats single-wavelet bound | single-trial transient HF bursts (gamma/beta) | no native MNE call — external array impl |

Key contrasts to remember:
- **STFT / multitaper** use a window length *fixed across frequencies* → **constant absolute** Hz resolution (`Fs / window_points`), but capture more cycles at high f (poor low-f timing).
- **Morlet** has temporal width proportional to `n_cycles / f` and frequency width proportional to `f / n_cycles`. Fixed cycles give constant relative frequency resolution; this skill's `n_cycles=f/2` gives constant absolute widths.
- **Hilbert** trades almost all frequency resolution for time resolution; it requires band-pass filtering into a band *first* and yields an instantaneous amplitude/phase envelope (the high-time-resolution path to band power and the foundation of band-limited PLV/ITC).

## Phase C — Per-Subject TFR Computation

For each subject and condition, write and execute a script:

### MNE-Python path (default)

```python
import mne
import numpy as np

epochs = mne.read_epochs(epoch_file, preload=True)

# Morlet wavelet TFR
freqs = np.arange(2, 40, 1)
n_cycles = freqs / 2.0

# Average power (ERSP equivalent)
power = mne.time_frequency.tfr_morlet(
    epochs, freqs=freqs, n_cycles=n_cycles,
    return_itc=False, average=True, decim=4, zero_mean=True,
    n_jobs=-1, verbose=True
)

# Inter-trial coherence (requires single-trial)
power_st, itc = mne.time_frequency.tfr_morlet(
    epochs, freqs=freqs, n_cycles=n_cycles,
    return_itc=True, average=True, decim=4, zero_mean=True,
    n_jobs=-1
)

# Apply the resolved baseline mode and keep its output units explicit.
baseline_mode = 'logratio'  # resolved from user input; default remains logratio
mne_mode = 'logratio' if baseline_mode == 'db' else baseline_mode
power.apply_baseline(baseline=(-0.5, -0.1), mode=mne_mode)
if baseline_mode == 'db':
    power.data *= 10       # log10 ratio -> dB
elif baseline_mode == 'percent':
    power.data *= 100      # MNE fractional change -> percent
# Label default logratio as log10 power ratio, never dB.

# Save
power.save(output_path, overwrite=True)  # .h5 format
itc.save(itc_output_path, overwrite=True)
```

**Alternative methods in MNE:**

- `mne.time_frequency.tfr_multitaper(epochs, freqs, n_cycles, time_bandwidth=4.0)` — Better frequency resolution, less spectral leakage. Use for narrow-band analyses (e.g., alpha sub-bands). `time_bandwidth` controls the frequency smoothing: higher = more tapers = smoother.
- `mne.time_frequency.tfr_stockwell(epochs, fmin=2, fmax=40)` — Automatic frequency-dependent resolution, no `n_cycles` parameter needed. Good for broadband analyses but computationally expensive.

### Superlets — single-trial transient high-frequency bursts (Moca et al. 2021)

The Morlet/multitaper/Stockwell trio serves **single-trial transient bursts** (gamma/beta) poorly: trial averaging blurs out bursts whose timing and frequency jitter, and any single wavelet is locked to one point on the time-frequency uncertainty curve. A **superlet** is the geometric mean of a *set* of Morlet wavelets with increasing cycle counts (an "order"); **adaptive superlets** raise the order with center frequency, beating the single-wavelet trade-off so you get sharp frequency resolution **and** good time localization at high frequencies simultaneously. There is **no native MNE call** — compute via an external array implementation (e.g. github.com/irhum/superlets) and wrap the result into an `AverageTFR` / `EpochsTFR` for downstream baseline/stats/figure handoff. Recommend specifically when the hypothesis concerns **transient bursts** rather than sustained rhythms (pairs naturally with the gamma myogenic guard above — confirm the burst is neural first). Cite: Moca, V. V., Bârzan, H., Nagy-Dăbâcan, A., & Mureșan, R. C. (2021). Time-frequency super-resolution with superlets. *Nat. Commun.*, 12, 337.

### Hilbert band-power path (highest time resolution)

When the question is the *timing* of band-limited activity (e.g. transient alpha suppression, single-trial envelopes) rather than its precise frequency, filter into the band and take the analytic-signal envelope — this is the high-time-resolution complement to Morlet/multitaper:

```python
# Per band of interest (filter FIRST, then Hilbert)
bands = {'theta': (4, 8), 'alpha': (8, 13), 'beta': (13, 30)}
for name, (lo, hi) in bands.items():
    ep_band = epochs.copy().filter(lo, hi, fir_design='firwin', verbose='error')
    analytic = ep_band.copy().apply_hilbert(envelope=False)    # complex analytic signal
    power_env = ep_band.copy().apply_hilbert(envelope=True)    # |Hilbert| = amplitude envelope
    # band power per trial = envelope.get_data()**2;
    # ITC per band = |mean(exp(1j*angle(analytic)))| over trials
```

Notes: `apply_hilbert` requires a **band-pass-filtered** signal (the analytic signal is only meaningful for a narrowband input); leave a filter transition margin inside the epoch (same COI logic as wavelets). Use this path, not Morlet, when you need per-sample band-power timing.

### Single-trial complex output (for ITC / single-trial analyses)

To compute ITC or per-trial power from arrays, request complex coefficients (`tfr_array_morlet` returns one coefficient per epoch — do **not** average first):

```python
# Complex per-trial coefficients via the array API
from mne.time_frequency import tfr_array_morlet
coefs = tfr_array_morlet(epochs.get_data(), sfreq=epochs.info['sfreq'],
                         freqs=freqs, n_cycles=n_cycles,
                         output='complex', zero_mean=True, n_jobs=-1)   # (n_epochs, n_ch, n_freqs, n_times)
from pathlib import Path
import runpy
itc_tools = runpy.run_path(str(Path(AEA_ROOT) / 'skills/eeg-tfr/scripts/itc.py'))
itc = itc_tools['itc_from_complex'](coefs, trial_axis=0)  # (n_ch, n_freqs, n_times)
power_st = (np.abs(coefs) ** 2)                                # single-trial power
```

This is the same phasor average that defines PLV between channels (applied to a phase *difference*); see `eeg-connectivity`.

## Phase D — Baseline Correction

Apply the approved baseline correction to **power** outputs. Raw ITC remains
a unitless phase-consistency measure in `[0,1]`; these power baseline modes
do not automatically apply to it. Label any separately approved ITC
transformation explicitly and keep the raw ITC.

1. Verify baseline window `[t_start, t_end]` falls entirely within the epoch.
2. Apply chosen mode:
   - `logratio` (default): `log10(power / mean(power_baseline))`, dimensionless. For requested `db`, multiply that result by 10 and label it dB.
   - `zscore`: `(power - mean(power_baseline)) / std(power_baseline)`.
   - `percent`: `100 * (power - mean(power_baseline)) / mean(power_baseline)`. Multiply the MNE `percent` result by 100 to obtain these percentage units. **Avoid** unless reproducing legacy analysis.
3. If no pre-stimulus period exists (e.g., resting-state): skip baseline, use raw power or log-transform. Document this in `TFR_PARAMS.json`.
4. For condition contrasts: apply baseline to each condition separately, then subtract. Do NOT compute contrast on raw power then baseline — this introduces bias (Cohen 2014, Section 18.5).

### Single-trial baseline for power–behavior regression (Hu et al. 2014)

The guidance above assumes trial-averaged ERSP. When power is correlated against behavior **trial-by-trial**, two extra issues bite: (1) pre-stimulus baseline power (especially alpha) **drifts as a hyperbolic function of trial ORDER** within a session, so a single grand baseline systematically biases early vs late trials — model trial-order drift (e.g. include trial index as a covariate). (2) Single-trial **percent/ratio** baseline overestimates ERS and underestimates ERD and is unstable on noisy trials, while single-trial **subtraction** baseline leaves the pre-stimulus fluctuation in the estimate; for single-trial power–behavior analyses, model the baseline as a **covariate** (or z-score power per trial) rather than dividing by it. Cite: Hu, L., Xiao, P., Zhang, Z. G., Mouraux, A., & Iannetti, G. D. (2014). Single-trial time–frequency analysis of electrocortical signals: baseline correction and beyond. *NeuroImage*, 84, 876–887.

## Phase E — Inter-Trial Coherence (ITC)

ITC (also called phase-locking factor, PLF) measures phase consistency across trials:

1. Compute single-trial complex spectral estimates (not averaged).
2. ITC at each time-frequency point: `ITC(t,f) = |mean(exp(i * phase(t,f,trial)))| across trials`.
3. ITC ranges from 0 to 1 (perfect phase-locking); random finite trial samples usually have positive ITC.
4. The definition discards amplitude magnitude, but observed phase estimates can still depend on signal-to-noise. A zero-amplitude complex coefficient has undefined phase; record/resolve its handling rather than assigning angle zero or adding an unapproved epsilon.
5. Resolve whether the target is a descriptive ITC, single-condition locking against an approved null, or a condition difference. Pure **trial-order shuffling within a condition leaves ITC unchanged**, so it is not a null for absolute locking. A Rayleigh test concerns an explicitly specified circular-uniformity null with its own assumptions; phase/time surrogates need an approved operation that changes alignment to the event. Do not choose one automatically.
5b. **ERSP vs ITC — keep them distinct in code.** ERSP (event-related spectral perturbation) = baseline-normalized *trial-averaged power* (average power **then** baseline). ITC = phase-locking computed from *single-trial complex coefficients* (`return_itc=True` on `tfr_morlet`, or `output='complex'` on `tfr_array_morlet`). You cannot recover ITC from an averaged power TFR — keep the complex/per-trial data.
5c. **ITC positive bias.** Report trial counts per participant/condition. With unequal counts, preserve the approved count-matching or inferential procedure; do not silently subsample. Exchanging condition labels can test an ITC **difference** when trials are exchangeable under that null. It does not establish absolute locking in either condition, and it does not itself remove finite-count bias from the reported raw magnitudes.
6. Save ITC as separate file: `tfr-stage/<sub>/<sub>-<cond>-itc.h5`.

The following example takes its target and null from `approved_itc_params`.
The optional label-test branch is deliberately limited to **one actual
participant**, two conditions, and exchange within the declared blocks.
Keep coefficient trial IDs aligned with the metadata; session/trial counts
are not independent participants. Multi-participant inference and other
nulls use their separately approved implementations.

```python
# AEA example: tfr-itc-target
from pathlib import Path
import runpy

params = approved_itc_params
itc_tools = runpy.run_path(str(Path(AEA_ROOT) / 'skills/eeg-tfr/scripts/itc.py'))
itc_values = itc_tools['itc_from_complex'](coefficients, trial_axis=params['trial_axis'])
route = itc_tools['inference_route'](
    target=params['target'], null_operation=params['null_operation'])
itc_test = None
if route == 'condition_label_exchange':
    itc_test = itc_tools['condition_label_test'](
        coefficients, trial_conditions, trial_axis=params['trial_axis'],
        participant_ids=participant_ids, conditions=params['conditions'],
        exchangeability_blocks=exchangeability_blocks,
        n_permutations=params['n_permutations'], seed=params['seed'],
        alternative=params['alternative'],
    )
elif route != 'descriptive':
    raise NotImplementedError('Use the separate approved test for this ITC target/null')
# Save raw ITC, axes, trial identities/counts and the resolved target.
# If computed, save itc_test['p_uncorrected'] separately; correct the planned
# channel/frequency/time test family before reporting significance.
```

The label-test helper computes `ITC(condition[0]) - ITC(condition[1])`,
preserves the observed condition counts within each exchangeability block,
and streams exceedance counts. Monte Carlo p-values use `(exceedances+1) /
(n_permutations+1)`, including identity permutations. Record the condition
order, blocks, alternative, seed and permutation count. Its pointwise
p-values are **uncorrected** and neither a population test nor a
multiple-comparison result.

### ITPC / ITLC — phase-only vs amplitude-weighted phase-locking (single-channel, across-trial)

ITC as defined above is the **inter-trial phase coherence (ITPC)** — the across-trial average of *unit* phasors (amplitude discarded). Tallon-Baudry & Bertrand (1996) also define the **inter-trial linear coherence (ITLC)**, which *weights each trial's phasor by its amplitude*, so trials with stronger oscillations contribute more. Both are **single-channel, across-trial** measures of evoked phase-locking / phase resetting — they are **not** inter-channel connectivity and **not** power.

```python
from pathlib import Path
import runpy
import numpy as np
from mne.time_frequency import tfr_array_morlet

# ---- ITPC via the high-level API (recommended, returns AverageTFR) ----
power, itc = epochs.compute_tfr(
    method='morlet', freqs=freqs, n_cycles=n_cycles,
    return_itc=True, average=True, decim=4, zero_mean=True, n_jobs=-1,
)
# itc is an AverageTFR; itc.data is in [0, 1], shape (n_ch, n_freqs, n_times).
# This is unit-phasor ITPC = |mean_trials exp(i*phase)| — amplitude is discarded.

# ---- ITPC and ITLC from complex coefficients (pure numpy, single-channel) ----
F = tfr_array_morlet(epochs.get_data(), sfreq=epochs.info['sfreq'],
                     freqs=freqs, n_cycles=n_cycles,
                     output='complex', zero_mean=True, n_jobs=-1)        # (n_trials, n_ch, n_freqs, n_times)
N = F.shape[0]                                            # trial count

# ITPC (== itc.data above): average of unit phasors
itc_tools = runpy.run_path(str(Path(AEA_ROOT) / 'skills/eeg-tfr/scripts/itc.py'))
itpc = itc_tools['itc_from_complex'](F, trial_axis=0) # (n_ch, n_freqs, n_times), in [0, 1]

# ITLC (Tallon-Baudry & Bertrand 1996): amplitude-weighted, normalised to [0, 1]
itlc = np.abs(np.sum(F, axis=0)) / np.sqrt(N * np.sum(np.abs(F) ** 2, axis=0))
```

Use ITPC when you want a power-independent index of phase consistency; use ITLC when stronger-amplitude trials should dominate the phase estimate (it is closer to the magnitude of the trial-averaged complex signal normalised by total energy). Both collapse the trial axis of a **single channel** — never the channel axis.

**When ITC matters:**
- Phase-consistent activity can contribute to an evoked average; a merely positive finite-sample ITC is not evidence of significant locking.
- High power with low ITC = induced (non-phase-locked) activity.
- High power with high ITC = evoked (phase-locked) activity.
- These are descriptive patterns, not significance tests or an isolation of induced power. Power baseline correction neither removes the evoked contribution nor defines an ITC null.

### Make "induced" power actually induced (Kalcher & Pfurtscheller 1995)

The skill labels high-power/low-ITC activity "induced" conceptually, but **total** power (the default `tfr_morlet` output) still contains the **evoked** (phase-locked) contribution — an ERSP/ERDS map called "induced" without an isolation step is mislabeled. To isolate genuinely induced power, subtract the evoked response from every trial *before* the TFR:

```python
# AEA example: tfr-power-time-grid
# This Morlet example applies when the plan requests these three power outputs.
params = approved_tfr_params
if params['method'] != 'morlet':
    raise ValueError('Use the approved TFR method; this example is Morlet only')
analysis_epochs = epochs.copy().pick(params['channels'])
erp = analysis_epochs.average(picks=analysis_epochs.ch_names)
induced = analysis_epochs.copy().subtract_evoked(erp)
# The synthetic epoch represents the ERP, not one independent participant/trial.
evoked_epoch = mne.EpochsArray(
    erp.data[None], erp.info.copy(), tmin=erp.tmin, baseline=None)
kwargs = dict(freqs=np.asarray(params['freqs']), n_cycles=params['n_cycles'],
    decim=params['decim'], zero_mean=params['zero_mean'], n_jobs=params['n_jobs'],
    picks=analysis_epochs.ch_names, return_itc=False, average=True)
power_total = mne.time_frequency.tfr_morlet(analysis_epochs, **kwargs)
power_induced = mne.time_frequency.tfr_morlet(induced, **kwargs)
power_evoked = mne.time_frequency.tfr_morlet(evoked_epoch, **kwargs)
for power in (power_total, power_induced, power_evoked):
    np.testing.assert_array_equal(power.times, analysis_epochs.times[::params['decim']])
    np.testing.assert_array_equal(power.freqs, params['freqs'])
    assert power.ch_names == analysis_epochs.ch_names
```

Retain the input tmin, actual times, channels, sampling rate and integer
decimation in `TFR_PARAMS.json`. The example preserves the original ERP time
origin instead of silently restarting at 0 s, and performs no additional
baseline correction or latency alignment. Compute only requested power types
in a study; all three above are shown together to check their shared grid.

Offer a `power_type: total|induced|evoked` option (default `total`). **Caveat to encode (Yeung et al. 2004):** ERP subtraction only removes phase-locked power if the evoked latency is *stable* across trials — with trial-to-trial latency jitter the average ERP is temporally smeared, subtraction is incomplete, and residual evoked energy leaks into "induced" power (and inflates ITC). Either latency-align trials first, or report **total power + ITC** rather than claiming a clean evoked/induced split. Cite: Kalcher, J., & Pfurtscheller, G. (1995). Discrimination between phase-locked and non-phase-locked event-related EEG activity. *Electroencephalogr. Clin. Neurophysiol.*, 94(5), 381–384; Yeung, N., Bogacz, R., Holroyd, C. B., & Cohen, J. D. (2004). Detection of synchronized oscillations in the electroencephalogram: an evaluation of methods. *Psychophysiology*, 41(6), 822–832.

## Phase F — ERDS Maps

Event-related desynchronization/synchronization (ERDS) maps (Pfurtscheller & Lopes da Silva 1999):

1. ERDS = baseline-corrected TFR expressed as percent change or dB.
2. ERD = power decrease (desynchronization) — negative values in logratio/dB.
3. ERS = power increase (synchronization) — positive values.
4. Standard ERDS bands:
   - Mu/alpha ERD (8–13 Hz): contralateral during motor planning/execution.
   - Beta ERD (13–30 Hz): during movement.
   - Beta ERS (13–30 Hz, "beta rebound"): post-movement, ~300–600 ms after movement offset.
5. For BCI/motor imagery studies: compute ERDS per channel, create topographic ERDS maps.
6. Save band-aggregated ERDS tables: `tfr-stage/<sub>/<sub>-erds-bands.csv` with columns `[subject, condition, band, channel, time_window, erds_value]`.

## Phase F2 — Standard TFR figure trio (preview/QC)

Produce a quick visual QC trio before handing off to `eeg-figure` (these are also the canonical deliverables). Always plot **baseline-corrected** TFR with a **symmetric** colour scale shared across conditions:

```python
# 1. Montage overview — TF image per channel laid out on the scalp
power.plot_topo(baseline=None, tmin=-0.2, tmax=1.0, fig_facecolor='w', font_color='k')

# 2. ROI channel(s) — single TF image (averages over picks)
power.plot(picks=['Cz', 'C1'], combine='mean', vlim=(-vmax, vmax), cmap='RdBu_r')

# 3. Band x time-window scalp topography (e.g. alpha 8-13 Hz, 80-420 ms)
power.plot_topomap(tmin=0.08, tmax=0.42, fmin=8, fmax=13, vlim=(-vmax, vmax))
```

- Canonical data axes order: **channels x freqs x times**.
- `plot(picks=...)` with `combine='mean'` **averages** the selected channels — state this when reporting an ROI figure.
- In MNE 1.12 `plot` / `plot_topomap` take `vlim=(min, max)` (not `vmin`/`vmax`); `plot_topo` still uses `vmin`/`vmax`. Fix `vmin = -vmax` for baseline-normalized (dB/logratio/percent) data and reuse the same `vmax` for every condition so panels are comparable.
- Group level: `grand = mne.grand_average([p1, p2, ...])` over per-subject `AverageTFR` objects, then re-run the same three plots.

Delegate publication figures to `eeg-figure`; this phase is for sanity-checking the TFR before stats.

### Gamma / high-frequency myogenic-artifact guard (Yuval-Greenberg et al. 2008; Hipp & Siegel 2013)

eeg-tfr treats >30 Hz like any other band, but **induced gamma-band power is frequently muscle, not brain**. The saccadic spike potential from miniature (micro)saccades plus cranial EMG produces a broadband transient that peaks ~200–350 ms post-stimulus over frontal and parieto-occipital sites, spans ~20–90 Hz with a peak near 65 Hz, and **survives standard ICA and amplitude rejection**. Bake these defaults in before trusting any >30 Hz result:

- Require **eye-tracker or radial-EOG (micro)saccade rejection** before reporting induced gamma — ordinary EOG channels miss microsaccades.
- Distrust **broadband / edge-rising** high-frequency power (a hallmark of EMG) and a stimulus-onset-locked transient burst rather than a sustained narrowband rhythm.
- Prefer **multitaper (DPSS)** over a single Morlet wavelet at high gamma (better variance control of the broadband estimate).
- **QC the HF TFR topography** (the `plot_topomap` panel above, fmin/fmax in the gamma band) for an edge- or temporalis-dominant (peripheral, non-cortical) spatial pattern before reporting any gamma effect.

Cite: Yuval-Greenberg, S., Tomer, O., Keren, A. S., Nelken, I., & Deouell, L. Y. (2008). Transient induced gamma-band response in EEG as a manifestation of miniature saccades. *Neuron*, 58(3), 429–441; Hipp, J. F., & Siegel, M. (2013). Dissociating neuronal gamma-band activity from cranial and ocular muscle activity in EEG. *Front. Hum. Neurosci.*, 7, 338.

## Phase G — Output Files

For each subject, produce:

### `tfr-stage/<sub>/<sub>-<cond>-tfr.h5`
HDF5 containing the averaged TFR (after baseline correction). Shape: `(n_channels, n_freqs, n_times)`.

### `tfr-stage/<sub>/<sub>-<cond>-itc.h5`
HDF5 containing raw unitless inter-trial coherence. Same axes as TFR; record
trial counts per participant/condition and retain aligned coefficient/trial
metadata for any approved inference. Save test outputs separately with the
target, null operation, exchangeability, seed/permutations and correction
status; do not label raw ITC or an uncorrected p-map as significant.

### `tfr-stage/<sub>/<sub>-erds-bands.csv`
Band-aggregated ERDS values for quick inspection and figure generation.

### `tfr-stage/TFR_PARAMS.json`
```json
{
  "method": "morlet",
  "freqs": [2, 3, "...", 39],
  "n_cycles": "freqs / 2 (adaptive)",
  "n_cycles_range": [1.0, 19.5],
  "decim": 4,
  "baseline_window": [-0.5, -0.1],
  "baseline_mode": "logratio",
  "edge_artifact_margin_s": 0.5,
  "srate_after_decim": 64,
  "n_subjects_processed": 24,
  "n_conditions": 2,
  "itc_computed": true,
  "erds_bands": {"theta": [4,8], "alpha": [8,13], "beta": [13,30], "gamma": [30,40]},
  "backend": "mne",
  "mne_version": "1.7.0"
}
```

### `tfr-stage/TFR_SUMMARY.md`
Per-subject summary: n_epochs used, edge artifact warnings, any subjects with excessive trial rejection.

## Phase H — Sanity Checks

All must pass before declaring success:

- [ ] Every subject in `epoch-stage/` has corresponding TFR output in `tfr-stage/`.
- [ ] `TFR_PARAMS.json` exists and all fields are populated.
- [ ] Baseline window falls within the pre-stimulus period (no overlap with stimulus).
- [ ] Edge artifact margin is documented; output time axis is trimmed if needed.
- [ ] If ANALYSIS_PLAN has TFR claims: requested frequency bands and time windows fall within computed ranges.
- [ ] ITC files exist if ITC was requested.
- [ ] No NaN or Inf values in output TFR arrays (check a random subset).
- [ ] File sizes are reasonable (H5 files should be < 500 MB per subject for typical EEG).

## Phase H2 — Time-frequency statistics hand-off

TFR data feed three multiple-comparison strategies (full details and code live in `eeg-stats`):

1. **Cluster-based permutation (preferred)** — respects TF/spatial contiguity, controls FWER. `mne.stats.permutation_cluster_1samp_test` / `spatio_temporal_cluster_test` on the `(n_subj, n_freq, n_time)` array.
2. **Mass-univariate pixel-wise + FDR** — a t-test at every (f, t) pixel, then `mne.stats.fdr_correction(p, alpha=0.05)`. Cheap, no contiguity assumption. The raw uncorrected p-map is **for visualization only** — never report it as significant.
3. **A-priori TF-ROI averaging** — if a band *and* window are hypothesized, average those axes per subject **first** (`tfr.crop(tmin, tmax)` then `.data[..., fband].mean(axis=(-1, -2))`) to one value per subject/channel, then run a single (optionally one-sided) test, FDR-correcting across channels only. Highest power, but the ROI must be pre-registered to avoid double-dipping.

Prepare the per-subject array for `eeg-stats` **after** baseline correction and **after** cropping the COI (Phase A step 4). State explicitly whether the test localizes "where" (collapse time+freq, cluster over channels), "when", or "what frequency".

## Failure Modes

| Symptom | Action |
|---|---|
| `epoch-stage/` missing | Stop. Run `eeg-epoch` first. |
| Edge artifact exceeds analysis window | Warn user. Trim output time axis or adjust `n_cycles`/frequency range. |
| NaN in TFR output | Check for flat channels or epochs with zero variance. Likely upstream issue — re-run `eeg-epoch` with stricter artifact rejection. |
| Memory error on single-trial TFR | Reduce `n_jobs`, process channels sequentially, or increase `decim`. |
| Baseline window overlaps stimulus | Stop. Adjust baseline window to be entirely pre-stimulus. |
| ITC values all near zero | Expected for induced (non-phase-locked) responses. Verify phase-locked responses (ERPs) exist before interpreting. |
| Extremely large H5 files (> 2 GB) | Increase `decim`, reduce frequency resolution, or save only frequency bands of interest. |
| Different trial counts across conditions | Warn. ITC is biased by trial count — equalize by subsampling if comparing ITC across conditions. |
| Effect/baseline window enters the sampled wavelet edge margin | Stop or warn. Widen input epochs by the maximum sampled half-support, approximately `max(5*n_cycles/(2*pi*freqs))` s per side, and recompute. With `n_cycles=f/2`, raising `f_min` does not reduce that margin. |
| `apply_hilbert` gives noisy/meaningless envelope | The input was not band-pass filtered. Filter into a single band first (`epochs.filter(lo, hi)`), then `apply_hilbert`. |
| Stockwell TFR very slow / memory-heavy | Expected for broadband `tfr_stockwell`. Narrow `fmin/fmax`, increase `decim`, or switch to Morlet. |
| ITC looks high but trial count is small | Positive bias at low N. Report N; compare against a shuffled-phase permutation null instead of the raw magnitude. |
| ITPC/ITLC inflated, or one condition higher purely because it has more rejected trials | Phase-resultant of finite N is non-zero even for random phase, so smaller N inflates the metric. Use an adequate trial count and **match N across conditions** (subsample to the smaller N, or average several random subsamples); never compare raw ITPC/ITLC across unequal trial counts. |
| ITPC/ITLC reported as "connectivity" or compared to power | Category error. ITPC/ITLC is single-channel, across-trial phase-locking — not inter-channel coupling (`eeg-connectivity`) and not power. Relabel; recompute the intended quantity if connectivity/power was actually wanted. |
