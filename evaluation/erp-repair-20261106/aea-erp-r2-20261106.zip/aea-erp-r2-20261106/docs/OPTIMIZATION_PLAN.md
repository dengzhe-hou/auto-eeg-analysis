# AEA Optimization Plan — derived from EEG reference collections

## 1. Executive summary — biggest wins

The 5 mined collections (FieldTrip/EEGLAB Chinese courses, the MNE-Python handbook/notebooks, COBIDAS-MEEG, and several method PDFs) surface a coherent set of high-confidence, high-frequency, **silent-validity** failures that AEA currently does not guard against. The largest wins cluster into four themes:

1. **Statistics correctness across the whole pipeline.** The single highest-leverage finding is the FieldTrip→MNE **two-tailed alpha double-halving trap** plus the missing **three-tier multiple-comparison policy** (cluster default / FDR sparse / Bonferroni last). `mne.stats.fdr_correction` is native MNE yet absent from `eeg-stats` entirely, and uncorrected per-frequency/per-channel/per-edge t-tests appear as a documented pitfall in *four* separate skills (stats, spectral, connectivity, tfr). Fixing this once in `eeg-stats` and threading it through `eeg-connectivity`, `eeg-spectral`, `eeg-tfr`, `eeg-methods-text`, and `eeg-audit` is the broadest single improvement.

2. **Design-aware test routing and subject-axis preservation.** Within- vs between-subject design must switch *both* the test statistic and the pairing/grouping variable — currently treated only as a test-name lookup. Paired with the **"never collapse the subject axis before cluster stats"** rule (and SEM = std(ddof=0)/√n band convention), this prevents two distinct, fatal, hard-to-detect errors. It touches `eeg-stats`, `eeg-erp`, `eeg-figure`, and is best enforced at the orchestrator level in `eeg-pipeline`.

3. **Leakage prevention in decoding and group regression.** Subject-wise CV (GroupKFold/LeaveOneGroupOut), no double-dipping (feature selection/PCA inside the Pipeline), nested CV with mean±std (not max) reporting, and the corrected `(C+1)/(n+1)` permutation p-value are all concrete, sklearn-native fixes for the most common accuracy-inflation patterns. The same subject-clustering logic re-appears in `eeg-behavior` as the mixed-effects-vs-OLS pseudoreplication fix.

4. **A genuinely new capability: `eeg-complexity`** (see §2), plus closing two missing-figure / missing-audit branches: connectivity matrices and source renderings in `eeg-figure`, and microstate + source-localization gates in `eeg-audit`.

**Confidence note.** Most proposals are high-confidence because they (a) map to verified MNE/sklearn/pycrostates/mne-connectivity APIs against stated versions (MNE 1.11.0), and (b) correct concrete code patterns observed in the mined scripts. The proposals also self-correct two mined errors honestly: MNE's Welch default is **`window='hamming'`, `n_overlap=0`** (not Hann+50% — `eeg-spectral` must set these explicitly), and the hand-rolled permutation p-values **omit the `+1` correction**. Speculative/lower-confidence items are flagged in §5.

---

## 2. New capability: `eeg-complexity`

**Status: proposed new skill (`is_new=true`), high confidence on structure, medium confidence on some library defaults.**

A complete new `SKILL.md` is drafted in AEA house style (frontmatter; Constants; Required Inputs; Phases A–H; Critical Rules; Domain Knowledge with citations; Failure Modes; Cross-references). It is marked **optional**, like `eeg-connectivity`.

Coverage:
- **Temporal entropy / Lempel-Ziv:** LZC (4 binarization rules, median default) and PLZC (the `m!`-normalization-base pitfall), Sample/Approximate entropy (m=2, r=0.15–0.2·SD, per-window SD; the **antropy-cannot-set-r** caveat is load-bearing), permutation entropy (order 3, normalize), Shannon amplitude entropy, wavelet entropy (db4 DWT), Hilbert-Huang spectral entropy.
- **RQA:** m=3, tau=1, r=0.5·SD; RR/DET/ENTR/L outputs; FNN/MI embedding guidance.
- **Scale-free / criticality:** specparam aperiodic slope + DFA/Hurst, the **H=(β−1)/2** bridge, and the longer-epoch (≥16 s) requirement.
- **Spatial complexity:** Omega/NSC/LCD with the **mandatory average-reference** rule.

Key load-bearing decision aids: a **per-metric library-selection table** (antropy / neurokit2 / EntropyHub / nolds — coverage is non-overlapping, so defaulting to antropy silently fails to honor a requested tolerance) and a **standardized sliding-window helper** (5 s window / 3 s overlap; ≥16 s for scale-free).

**Honest caveat:** the algorithms and parameter conventions are high-confidence (taught explicitly in the references), but the exact library→function mappings and the antropy-r limitation should be smoke-tested against the installed package versions before shipping the Constants block as authoritative.

---

## 3. Per-skill change summary

| Skill | #high | #med | Key additions |
|---|---:|---:|---|
| **eeg-stats** | 6 | 6 | 3-tier MC policy + `fdr_correction`; cluster-forming vs cluster-level threshold + anti-double-halving; design→test routing; TF-stats subsection; `f_mway_rm` factorial; src-cluster note; keep-subject-axis/SEM |
| **eeg-connectivity** | 5 | 7 | `spectral_connectivity_time` (task/time-resolved); metric-coverage table + out-of-scope MI/TE/SL; volume-conduction subsection + CSD; per-edge FDR + NBS stats; condition-matched common filter; Granger gc_tr + model order |
| **eeg-tfr** | 4 | 9 | Method-selection table (STFT/Morlet/**Hilbert**); n_cycles σ_t formula + window table; COI/crop guard; plotting trio; TF-stats hand-off; STFT & Hilbert domain entries |
| **eeg-spectral** | 4 | 4 | Explicit Welch window/overlap (correct MNE default = hamming/0); resolution + zero-padding + LP-cap; units box (2/N, no double-normalize); group-PSD + MCC; Hurst conversion |
| **eeg-complexity** *(new)* | 9 | 3 | Entire skill (see §2) |
| **eeg-microstate** | 6 | 5 | Filter 1-40→**2-20 Hz**; GFP-peak fix (ms not samples) + subsample/reject; "Selecting K" + polarity-invariance warning; smoothing provenance; base-rate transition matrix; correct `compute_parameters()` API |
| **eeg-source** | 7 | 6 | **Average-reference gate** for beamforming; **DICS**; condition-matched common filter; programmatic coreg + `plot_alignment` verify; volume source space; morph/atlas reporting; src-cluster x-ref |
| **eeg-decoding** | 5 | 5 | Subject-wise CV (GroupKFold/LOGO); no-double-dipping Pipeline; nested CV (report mean not max); corrected `(C+1)/(n+1)` p + narrower stats window; crossnobis RSA; mne-features tabular path |
| **eeg-preprocess** | 3 | 6 | ICA rank arithmetic (n = m − interpolated − avgref); bad-segments / sandwich method; raw artifact taxonomy; drop non-scalp before avg-ref; CSD; resample-before-Epochs |
| **eeg-ica** | 5 | 1 | SASICA measure→MNE table (find_bads_eog/ecg/muscle, dipole RV<15%); correlation pass; visual-signature table; "when in doubt, keep"; rank arithmetic |
| **eeg-erp** | 3 | 4 | Per-condition trial counts + correction>rejection + SNR∝√n; Phase D.5 hypothesis vs data-driven group stats; SEM band + keep-individual-arrays |
| **eeg-methods-text** | 3 | 5 | Source-analysis reporting rows; MC-policy + threshold-derivation domain entries; two ERP-stats-route boilerplates; gated BibTeX |
| **eeg-figure** | 0 | 9 | Missing **connectivity-matrix/circle** panel + diagonal masking; missing **source-estimate** panel + morph rule; TFR trio (`plot_topo`); `plot_compare_evokeds` SEM band |
| **eeg-epoch** | 3 | 4 | Tighten threshold 150→~100 µV (60–75 clean); resting `make_fixed_length_epochs` (baseline=None); resolution=1/duration rule |
| **eeg-audit** | 3 | 3 | Microstate reliability gate (Khanna 2014); source coreg-not-identity gate; localization-justification gate (template-BEM → ROI/lobar only) |
| **eeg-behavior** | 2 | 3 | Mixed-effects model for pooled single-trial (vs OLS pseudoreplication); subject-leakage rule for predictive validation |
| **eeg-pipeline** | 2 | 2 | Design-resolution pre-flight (route stats branch + validate n); cross-stage ordering invariants (filter→resample, never resample Epochs, reref/ICA-rank) |
| **eeg-report** | 0 | 2 (+1 low) | Microstate norm bands + clinical directions (gated to microstate outputs) |
| **eeg-recipe** | 3 | 2 | `complexity?` stage; state-tracking recipe class (continuous, no markers); eyes-open>closed sanity check |

*(Counts reflect the priority tags in each proposal's `changes` list; "low" items omitted from the columns but noted where relevant.)*

---

## 4. Top-15 concrete changes to implement first

Ranked by (breadth × confidence × cost-of-getting-it-wrong). All are high-confidence unless noted.

| # | Skill | What | Why | Source |
|---|---|---|---|---|
| 1 | eeg-stats | Add the **three-tier multiple-comparison policy** (cluster default / FDR for sparse / Bonferroni last) and wire in `mne.stats.fdr_correction`, which is currently absent. | The most pervasive correctness gap; uncorrected maps recur as a pitfall in 4 sibling skills. FDR is native MNE and treated as the lightweight default by the references. | MNE notebook cells 81-87, 127; COBIDAS |
| 2 | eeg-stats | Document **cluster-forming vs cluster-level threshold** with the "MNE handles two-sidedness — do not double-halve" warning and df-derived `t.ppf(1-alpha/2, df)`. | The FieldTrip→MNE 0.025 double-halving is a silent off-by-factor bug; df rule differs by design. | find_tvalue.m L16-28; TFR_topography_test.m L30-50 |
| 3 | eeg-stats / eeg-pipeline | **Design→test routing:** within→`spatio_temporal_cluster_1samp_test` (paired), between→`spatio_temporal_cluster_test`; validate n from the plan **before** invoking stats. | Wrong pairing is a silent validity failure; the orchestrator owns the routing decision. | TFR_topography_test.m L53-66; notebook cells 89-95 |
| 4 | eeg-stats / eeg-erp / eeg-figure | **Never collapse the subject axis before cluster stats**; standardize SEM = std(ddof=0)/√n bands (`plot_compare_evokeds`). | Averaging before stats destroys the test input — fatal and silent; band convention is currently undefined. | notebook cells 65-71, 121; keepindividual='yes' |
| 5 | eeg-decoding | **Subject-wise CV rule:** mandate GroupKFold/LeaveOneGroupOut with `groups=subject` when trials are pooled across subjects. | Single most common source of inflated cross-subject decoding accuracy; sklearn-native, no hand-rolled splitter. | 15subject-wise_one_stage.py; course "data leakage" |
| 6 | eeg-decoding | **No double-dipping:** wrap feature selection / PCA inside the `Pipeline` (fit on train fold only); method→sklearn map; `f_classif` not chi2 for signed EEG. | The mined course fits selectors on the whole dataset — the most damaging leakage pattern. | 17feature_sel_basic_data.py |
| 7 | eeg-decoding | Replace naive permutation p with the corrected **`(C+1)/(n+1)`** form (or `permutation_test_score`); test a **post-stimulus** window with explicit chance, `tail=1`. | Naive p can equal 0; testing the baseline inflates clusters. Corrects a real bug in the mined script. | 12svm_whole.py; notebook cells 155-163 |
| 8 | eeg-source | **Average-reference gate before beamforming** (hard requirement) + condition-matched common spatial filter (one filter on pooled data, applied per condition). | Forward-model contamination and between-condition bias are both silent; the course's hardest, most-emphasized gate. | Beaformer1/2.m; fc_source_main.m |
| 9 | eeg-connectivity | Add **`spectral_connectivity_time`** for task/time-resolved FC (currently only the whole-epoch `_epochs` estimator exists). | Without it the agent cannot do event-related time-resolved connectivity at all — a capability gap, not a refinement. | PS_computation.m; sub_stft.m; FC course task recipe |
| 10 | eeg-connectivity | Add a **Statistics section**: per-edge FDR over the upper triangle + NBS network-level correction (flagged not-in-MNE-core, with permutation recipe). | Connectivity stats are a multiple-comparisons minefield; the skill has no stats section at all. | rest_fc_test.m; fc_scalp_main.m; 功能连接分析1.pdf |
| 11 | eeg-tfr | Add a **method-selection table** (STFT constant-absolute vs Morlet constant-relative resolution) including the entirely-absent **Hilbert-on-narrowband** path (`Epochs.filter` + `apply_hilbert`). | Highest-value structural addition; Hilbert is a genuine missing high-time-resolution capability. | tfd.pdf p.1-2 |
| 12 | eeg-microstate | Correct the default filter band from **1-40 Hz to 2-20 Hz**, and fix GFP-peak extraction (`min_peak_distance` is in **samples** derived from 10 ms, not "10 samples"); add per-subject subsampling + SD rejection. | Wrong field default + a units bug that is dangerously small at high sfreq; both propagate through the skill. | microstate_notes.pdf item 5; Poulsen 2018 §3.3.2; pycrostates API |
| 13 | eeg-microstate | Fix Phase F: the current code imports non-existent `pycrostates.metrics.*`; replace with `Segmentation.compute_parameters()` and base-rate-corrected transition matrices. | The current code does not run against the real pycrostates API — a hard correctness bug. | pycrostates segmentation API (verified) |
| 14 | eeg-spectral | Set Welch **window/overlap explicitly** (Hann + 50% overlap), correcting the mined claim — MNE 1.11 defaults to `window='hamming'`, `n_overlap=0`; add the units box (2/N single-sided; never re-normalize MNE PSD). | Silent spectral leakage from inherited defaults + a real double-normalization hazard for MATLAB-FFT users. | fft_rest.m; verified MNE 1.11.0 psd_array_welch defaults |
| 15 | eeg-preprocess / eeg-ica | State the **ICA rank arithmetic** explicitly: `n_components = m_channels − n_interpolated − (1 if average-referenced)`, and propagate `n_interpolated` to the ICA stage. | The most common practical ICA mistake; the skill interpolates but never carries the count forward. | preprocessing_batch.m L99 (`pca,m-n`); 220723-preprocessing.pdf |

---

## 5. Cross-cutting items

### New recipes worth adding (medium confidence)
- **State-tracking / complexity-for-anesthesia recipe** (`eeg-recipe` + new `eeg-complexity`): continuous, no per-trial markers; `make_fixed_length_epochs` windowing (5 s / 3 s overlap; ≥16 s for scale-free); built-in **eyes-open > eyes-closed** complexity sanity check; the trial-count gate must switch to a per-state duration/window-count check. This is the headline use case driving the new `eeg-complexity` skill. *Caveat:* the anesthesia directional predictions (LZC/SampEn/PE down, RR up under deep anesthesia) are well-supported in the literature but the demo `.m` files are not citable — anchor to a peer-reviewed reference (e.g. Zhang/Roy/Jensen 2001 IEEE TBME) in the recipe's claim table.
- **Resting-state microstate recipe** (`eeg-microstate` + `eeg-report`): two-stage "global maps" group workflow (Khanna 2014, Cronbach α 0.81 vs 0.52 for per-recording), reliability preconditions (≥20 ch, ≥180 s, average reference), and report norm bands (80–120 ms duration, ~10/s occurrence, ~70% GEV for K=4) gated to microstate outputs only.
- **Resting-state spectral / connectivity recipe**: fixed-length 2 s epochs (`baseline=None`), per-band loop, the resolution = 1/duration link, and mandatory MCC on the group PSD/edge tests.

### New dependencies
| Package | Needed by | Notes |
|---|---|---|
| `antropy` | eeg-complexity | Cannot set tolerance `r` for SampEn — must fall back to neurokit2/EntropyHub when a specific r is requested (this is a load-bearing caveat, not a nuisance). |
| `neurokit2` | eeg-complexity | Full tolerance control; RQA. |
| `EntropyHub` / `nolds` | eeg-complexity | Coverage gaps the others miss; non-overlapping. |
| `mne-features` | eeg-decoding | Tabular feature-decoding path (`extract_features`). |
| `mne-rsa` | eeg-decoding | Cross-validated RDM / crossnobis RSA. |
| `pycrostates` | eeg-microstate | Already implied; verify the `Segmentation.compute_parameters()` / transition-matrix API surface (the current SKILL imports functions that do not exist). |
| `mne-connectivity` | eeg-connectivity | Confirm `spectral_connectivity_time` is present in the pinned version. |

All are separate pip packages with separate import names; `eeg-decoding` and `eeg-complexity` should degrade gracefully (clear "optional dependency missing" failure mode) rather than crash.

### Docs / PLATFORM_SUPPORT note (Windows + conda) — **flag, medium confidence**
The mined material doesn't directly establish a Windows MKL bug, so treat this as a **precautionary doc note rather than a verified fix**: on Windows the user runs MNE via a conda environment, and the heavy numerical additions proposed here (cluster permutation with `n_jobs>1`, `f_mway_rm`, FOOOF/specparam, the new complexity libraries, NBS permutations) are exactly the workloads that hit the known **conda/MKL `KMP_DUPLICATE_LIB_OK` / OpenMP-thread-oversubscription** pitfall — joblib parallel + MKL can deadlock or silently fall back to a single core. Add a `PLATFORM_SUPPORT.md` note recommending: pin `n_jobs` explicitly, prefer `MKL_NUM_THREADS=1` when using joblib parallelism, and document the per-package install channel. This should be **verified on the actual `sms` / Windows conda env before being asserted as fact** in any skill body.

### Consistency / sequencing guidance
- Implement **#1–#4 (eeg-stats core) first** — five other skills cross-reference the MC policy, threshold derivation, and keep-subject-axis rule, so landing them upstream avoids divergent copies.
- The **subject-leakage logic (#5)** and the **`eeg-behavior` mixed-effects fix** are the same idea in two frames (CV vs random-effects) — write the citation set once (Varoquaux 2017; Volpert-Esmond 2021) and reference from both.
- The **average-reference + common-filter rules** must land in `eeg-source`, `eeg-connectivity` (source FC), and `eeg-audit` (the localization-justification gate) together, or the audit will flag valid pipelines / pass invalid ones.
- After landing, run `eeg-audit`'s new microstate/source gates against an existing ERP-only project to confirm the new verdict arrays stay **empty (additive, non-breaking)** for non-microstate/non-source studies.

### Honest confidence ledger
- **High confidence:** all statistics-correctness items (#1–#4, #7, #10), subject-leakage/double-dipping (#5–#6), the microstate API/units fixes (#12–#13), the Welch-default correction (#14), ICA rank arithmetic (#15), and the missing figure/audit branches. These correct observed code patterns or verified API signatures.
- **Medium confidence:** the `eeg-complexity` library→function defaults (smoke-test before shipping), the anesthesia recipe directional predictions (citable but demo-sourced), and DICS/coreg API details (stated as verified against MNE 1.11.0 but worth a one-line import check).
- **Speculative / verify-before-asserting:** the Windows conda/MKL PLATFORM_SUPPORT note, and any NBS recipe (explicitly not in MNE core — ship as a documented permutation recipe, not an API call).