# AEA Manifesto — what this is, what it isn't, and why it can win

> If you read one document in this repo, read this one.

## The blunt truth about EEG software

Every lab writes their own EEG pipeline because the existing ones are:

- **Too rigid** (HAPPE, Automagic, DISCOVER-EEG): one set of parameters, designed for one population.
- **Too flexible** (MNE-BIDS-Pipeline, FieldTrip): you still write a 200-line config and group stats are your problem.
- **Too narrow** (PREP): only does preprocessing; you build the rest.
- **Too coupled** (EEGLAB STUDY, Brainstorm): tied to a GUI you can't script around.
- **Not paper-aware**: none of them generate paper-ready figures + COBIDAS-MEEG-compliant methods text + reviewer-anticipation report. That gap is universal.

So we keep reinventing the wheel. AEA is built on the bet that **the right unit of EEG-analysis sharing is not the toolbox, not the script, but the *recipe*** — a paradigm-specific Markdown file that anyone can apply to their data.

## The three things AEA does that nothing else does

### 1. The Recipe Hub

A recipe is a single Markdown file under `recipes/<paradigm>/RECIPE.md`. It declares:

- The paradigm (N170 face inversion, P300 oddball, alpha attention…)
- The published reference it's derived from
- Required data shape (channels, marker codes, conditions)
- The exact pipeline (preprocess params, ICA strategy, epoch window, contrasts)
- Expected outputs (figures, stats, COBIDAS methods paragraph)

Researcher A publishes a recipe alongside their paper. Researcher B clones AEA, drops their data in, runs `/eeg-recipe n170-face-inversion projects/my-data`, gets a side-by-side reproduction. **This is what HuggingFace did for models. EEG has never had it.**

### 2. Auto COBIDAS-MEEG methods text

Every paper using EEG needs a methods section that lists: acquisition system, sampling rate, online filter and reference, offline preprocessing, ICA criteria, epoch criteria, exclusion rules, statistical test with permutations and seeds and adjacency. **Nobody does this section in less than two days of writing.**

AEA reads `DATASET_BRIEF.md` + every stage's `BACKEND_RESOLUTION.md` + `stats-stage/*.json` and emits a paragraph that satisfies the COBIDAS-MEEG checklist (Pernet et al. 2020). Reviewers love it. Authors love it more.

### 3. Reviewer-anticipation reports

Before submitting, run `/eeg-audit — reviewer-mode: adversarial`. An external LLM (Codex MCP, gpt-6-astra, max effort) takes the role of a hostile EEG reviewer and writes the rejection memo *you would otherwise get from Reviewer 2*: "your cluster threshold is non-standard", "you didn't report adjacency", "your bandpass is too aggressive for the time window of interest", "your montage choice biases parietal effects". You fix or rebut **before** submission, not after.

## How AEA actually works (and why there's no code)

AEA follows its parent framework ARIS's architecture exactly: **markdown-only, no framework, no daemon**. Skills are methodology documents — structured Markdown files that tell the LLM what to do. The LLM reads the skill, reads your data, and writes the analysis code itself at runtime. There are no pre-written analysis scripts anywhere in this repo.

The only code files are utility tools: `auto_brief.py` for metadata extraction from raw EEG files, `check_env.sh` for environment probing. Everything else is prose — opinionated, citation-backed, methodology-encoding prose.

This is a deliberate choice. Pre-written scripts are brittle: they break when data shapes change, when MNE updates an API, when a reviewer demands a different statistical approach. LLM-generated code from a well-specified methodology document adapts to all of these. The methodology stays stable; the code is disposable.

## The real moat: codified domain expertise

AEA differs from ARIS in one fundamental way: **domain specialization through knowledge codification**.

ARIS is a generic research automation framework — its skills describe workflows. AEA's skills and recipes encode **distilled EEG domain expertise** that no generic agent possesses. This expertise comes from three sources:

### Source 1: Expert methodologists

The skills encode guidelines from the people who literally wrote the standards:

- **Cyril Pernet's** COBIDAS-MEEG reporting checklist — what your methods section *must* contain
- **Sara Robbins'** PREP pipeline standards — reference, line noise, interpolation done right
- **Nima Bigdely-Shamlo's** clean_rawdata guidelines — automated rejection that reviewers accept
- **Stefan Debener's** mobile EEG best practices — when your data isn't from a shielded room
- **Robert Oostenveld's** FieldTrip conventions — the other half of the EEG world's expectations

These aren't vague nods to authority. The skills contain their specific parameter recommendations, their published thresholds, their stated caveats.

### Source 2: Landmark papers' analysis methods

Each recipe captures the **exact analysis pipeline** from a high-impact published EEG study:

- **Rossion et al. 2003** → N170 parameters: which channels, which time window, which baseline, which contrast
- **Polich 2007** → P300 paradigm: oddball ratio, epoch length, component extraction method
- **Worden et al. 2000** → Alpha attention protocol: lateralization index, frequency band, cue-target interval

The recipe IS the paper's method section, made executable. A PhD student reading the original paper would spend days extracting these details from dense prose, supplementary materials, and personal communications with the authors. The recipe has already done that work.

### Source 3: Open-source tool best practices

The skills encode the current recommended workflows from the tools themselves:

- **MNE-Python's** ICA + ICLabel pipeline — the exact sequence, the gotchas, the parameters that actually work
- **AutoReject's** validated rejection parameters — not the defaults, the ones from their validation paper
- **Cluster permutation testing** conventions from MNE documentation and the broader EEG literature — adjacency matrices, tail settings, number of permutations that reviewers won't reject

### Why this matters

Every recipe is a compilation of scattered domain knowledge into a single executable file. Knowledge that currently lives in:

- Papers (behind paywalls, buried in supplementary materials)
- Tutorials (often outdated, sometimes wrong)
- Mailing list threads (MNE, EEGLAB, FieldTrip — decades of Q&A)
- Stack Overflow answers (upvoted doesn't mean correct)
- Lab wikis (private, inaccessible)
- "Ask your advisor" (doesn't scale)

AEA's moat is not the code — there is no code. It's the **curated, validated, citation-bound methodology** that would take a PhD student weeks to piece together. The LLM can write `mne.preprocessing.ICA(n_components=15, method='infomax')` on its own. What it can't do on its own is know that for your paradigm, with your channel count, infomax with 15 components is the right call, that Pernet et al. recommend reporting the explained variance, and that Reviewer 2 will reject you if you don't justify your component selection criteria. That's what the skill encodes.

## What AEA is NOT

- **Not a wrapper around MNE-Python.** It uses MNE-Python (and FreeSurfer, Pycrostates) but the value is the methodology layer above them.
- **Not a config-file pipeline.** MNE-BIDS-Pipeline does that, well. AEA is for analyses where you'd rather say "compare alpha desync between conditions in parietal channels 0.4–0.8 s post-cue" than write 200 lines of YAML.
- **Not for online/real-time analysis.** Offline-only.
- **Not a drop-in replacement for whatever you use now.** It's designed to coexist: import your cleaned `.set` or `.fif`, run AEA from there.

## Why this can win

### The adoption math

EEG community is conservative — most labs are MATLAB-native and suspicious of "AI hype". The migration cost from a working pipeline to a new one is the killer. AEA sidesteps this:

- **Zero migration**: works alongside your existing pipeline. Bring your cleaned data in any format; AEA handles the next steps.
- **One-command reproduction**: clone repo, run `/eeg-recipe <paradigm>`, get the figure + methods text. No framework to learn.
- **Markdown-only**: no daemon, no Docker, no database. The whole thing is human-readable, fork-able, modifiable.

### The flywheel

```
A researcher writes recipe for their paradigm
        ↓
Other researchers reproduce + cite
        ↓
Recipe author gets a citation hit
        ↓
More researchers contribute recipes
        ↓
Recipe library becomes the canonical EEG analysis archive
```

This worked for HuggingFace (models), Papers With Code (benchmarks), and ARIS (research workflows). EEG has never had it because no one has built a tool that treats analyses as **shareable artifacts** rather than scripts buried in supplementary materials.

### The defensibility

If someone clones the idea, they have to also build:
- 19 SKILL.md files (6306 lines, ~38 papers distilled) with cross-platform multi-backend instructions (done in this repo)
- A growing library of validated recipes (network effect)
- Codex/Cursor/Claude integrations (already done — markdown skills are universal)

The recipe library is the moat. Everything else is commodity.

## What we need to ship

To go from "scaffolding" to "EEG researchers actually use this":

### Phase 0 — make it real (✅ COMPLETE)
- ✅ 19 SKILL.md files (6306 lines, ~38 papers), env probes
- ✅ End-to-end runs on `mne.datasets.sample` + ERP CORE — 3 case studies completed
- ✅ 4 recipes (N170, P300, alpha-attention, ERN-flankers) backed by published papers

### Phase 1 — make it usable (✅ COMPLETE)
- ✅ All core skills fleshed out and verified: preprocess, ICA, epoch, ERP, TFR, stats, figure
- ✅ `eeg-methods-text` auto-COBIDAS skill — demonstrated in 3 case studies
- ✅ `eeg-audit` adversarial reviewer — 2-round audit loop (FAIL → PASS) demonstrated
- ✅ New analysis skills: eeg-spectral (FOOOF/IAPF), eeg-decoding (MVPA), eeg-behavior (RT/EEG correlation)

### Phase 2 — make it findable (in progress)
- Demo video: "Reproduce a Nature Neuroscience EEG figure in 5 minutes from raw data"
- Submit to: r/neuroscience, MNE/EEGLAB mailing lists, EEG/MEG twitter (Kay Robbins, Cyril Pernet, Matt Craddock, Dorothée Hoppe)
- Conference posters: OHBM, CCN, SfN
- Awesome-lists: awesome-eeg, awesome-agent-skills (where ARIS is featured)

### Phase 3 — make it sticky (next 6 months)
- 20+ community-contributed recipes covering the major paradigms
- Integration with EEGLAB STUDY (read existing analyses, port to AEA recipe)
- Recipe-library web index (browse without cloning)
- Cite-recipe button: when a recipe runs, it tells the user the BibTeX for the original method paper

## The opinion

The bet is that EEG is overdue for the kind of cultural shift HuggingFace caused in NLP. The tooling will keep improving incrementally on its own; what's missing is **a sharable, verifiable, paradigm-specific unit of analysis**. AEA is the smallest viable bet on that unit being a Markdown recipe.

If I'm wrong, the worst case is that the user has a personal automation system that saves them time. If I'm right, we're at the start of an ecosystem.
