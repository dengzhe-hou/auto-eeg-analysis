"""Select only task-matching procedures for the explicit approved ERP plan schema.

No reference answers, participant outcomes or experiment scoring files are read.
This prepares a new resource condition; it does not alter any frozen evaluation.
"""
import argparse
import json
from pathlib import Path

from prepare_skill_packet import prepare_packet


def prepare_erp_packet(root, plan):
    if plan['request_kind'] not in ('single_subject', 'group'):
        raise ValueError('Select single_subject or group for this ERP packet route')
    selections = [{'skill': 'eeg-epoch', 'section': 'Approved ERP execution',
                   'scripts': ['scripts/erp.py']}]
    contrast = plan['derivatives']['contrast_label']
    if plan['dataset']['name'] == 'ERP CORE' and contrast == 'errorminuscorrect':
        selections.append({'skill': 'eeg-epoch', 'section': 'ERP CORE response coding',
                           'scripts': ['scripts/erp_core_events.py']})
    if plan['request_kind'] == 'group':
        selections.append({'skill': 'eeg-epoch', 'section': 'Approved ERP group statistics'})
    packet, receipt = prepare_packet(Path(root), selections)
    source = 'tools/check_erp_outputs.py'
    checker = (Path(root) / source).read_text(encoding='utf-8-sig')
    packet += f'\n\nAEA procedure: {source}\n\n{checker}'
    receipt.update(additional_sources=[source], packet_characters=len(packet),
                   request_kind=plan['request_kind'], contrast_label=contrast,
                   selection_basis='Public request kind, dataset and contrast only; no reference outcomes')
    return packet, receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--receipt', type=Path, required=True)
    args = parser.parse_args()
    packet, receipt = prepare_erp_packet(args.root, json.loads(args.plan.read_text(encoding='utf-8')))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(packet, encoding='utf-8')
    args.receipt.parent.mkdir(parents=True, exist_ok=True)
    args.receipt.write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')


if __name__ == '__main__':
    main()
