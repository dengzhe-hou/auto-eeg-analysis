#!/usr/bin/env bash
# Sync the manuscript sources between paper/ (ARIS working copy, audited) and paper-overleaf/
# (git clone of Overleaf project 6aa7b667c6b89aa2dc39455e). Only compile sources travel; audit
# reports, PDFs, prompts and .aris/ stay in this repository.
#   tools/overleaf_sync.sh push ["commit message"]   copy paper/ -> paper-overleaf/, commit, push
#   tools/overleaf_sync.sh pull                       git pull --ff-only, then list files that differ from paper/
#   tools/overleaf_sync.sh status                     remote-vs-local and paper/-vs-clone divergence
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/.." && pwd); SRC="$ROOT/paper"; OL="$ROOT/paper-overleaf"
[ -d "$OL/.git" ] || { echo "paper-overleaf/ is not a git clone; clone https://git.overleaf.com/6aa7b667c6b89aa2dc39455e first" >&2; exit 1; }
files() { printf '%s\n' main.tex references.bib figures/fig1_chain.pdf figures/fig2_n400.pdf; }
differ() { for f in $(files); do if [ ! -f "$OL/$f" ] || ! cmp -s "$SRC/$f" "$OL/$f"; then echo "$f"; fi; done; }
case "${1:-status}" in
  push)
    git -C "$OL" pull --ff-only -q
    n=0; for f in $(differ); do mkdir -p "$OL/$(dirname "$f")"; cp "$SRC/$f" "$OL/$f"; n=$((n+1)); done
    echo "files copied: $n"; git -C "$OL" status --short
    if [ -n "$(git -C "$OL" status --porcelain)" ]; then
      git -C "$OL" add -A; git -C "$OL" commit -q -m "${2:-aea: sync manuscript sources from auto-eeg-analysis@$(git -C "$ROOT" rev-parse --short HEAD)}"; git -C "$OL" push -q; echo "pushed $(git -C "$OL" rev-parse --short HEAD)"
    else echo "nothing to push"; fi ;;
  pull)
    before=$(git -C "$OL" rev-parse HEAD); git -C "$OL" pull --ff-only -q; after=$(git -C "$OL" rev-parse HEAD)
    [ "$before" != "$after" ] && git -C "$OL" diff --stat "$before..$after" || echo "Overleaf: no new commits"
    echo "files differing between paper-overleaf/ and paper/ (review each hunk before copying back):"; differ | sed 's/^/  /' ;;
  status)
    git -C "$OL" fetch -q; b=$(git -C "$OL" branch --show-current)
    echo "remote ahead: $(git -C "$OL" rev-list --count HEAD..origin/$b) | local ahead: $(git -C "$OL" rev-list --count origin/$b..HEAD)"
    echo "files differing between paper/ and paper-overleaf/:"; differ | sed 's/^/  /' ;;
  *) echo "usage: $0 push [msg] | pull | status" >&2; exit 2 ;;
esac
