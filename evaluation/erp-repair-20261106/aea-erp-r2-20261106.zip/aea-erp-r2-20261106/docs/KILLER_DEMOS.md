# Killer Demos — what only AEA can do

A list of capabilities that distinguish AEA from MNE-BIDS-Pipeline, HAPPE, PREP, Automagic, DISCOVER-EEG, BeMoBIL, EEGLAB STUDY, Brainstorm protocols. Each demo gates a release: if it doesn't work end-to-end, the version doesn't ship.

## D1. Recipe drive-by reproduction ✅ DEMONSTRATED

**Pitch:** *"Reproduce a published EEG finding from raw data in five minutes. No config file."*

> **Status:** Validated with `ern-flankers` recipe on ERP CORE data. 3 claims, 6-panel figure, 94.6 seconds from raw BDF to publication figure.

```bash
# Clone AEA, point at any compatible dataset, get the same figure as the paper
git clone https://github.com/<you>/auto-eeg-analysis
cd auto-eeg-analysis
claude
> /eeg-recipe n170-face-inversion --data ~/my-eeg-experiment/
```

Output: `figure-stage/F1_N170_face_inversion.svg` + a methods paragraph + a BibTeX entry pointing to the original paper the recipe is based on.

**What no one else does:** existing pipelines need ~200 lines of config to run an analysis; recipes carry the config inside them, paradigm-specifically, with provenance.

## D2. Auto COBIDAS-MEEG methods paragraph ✅ DEMONSTRATED

**Pitch:** *"Stop writing your methods section by hand. AEA reads every step's log and emits a paragraph that satisfies the COBIDAS-MEEG checklist."*

> **Status:** Demonstrated in all 3 case studies. Methods text auto-generated from pipeline logs, covering acquisition, preprocessing, ICA, epoching, stats, and seed/version info.

```
> /eeg-methods-text projects/my-study --venue NeurIPS

# Output (excerpt):
EEG was recorded from 64 Ag/AgCl active electrodes (BioSemi ActiveTwo) at 2048 Hz with
a 0.1–100 Hz online bandpass and CMS/DRL reference. Offline, data were resampled to 250 Hz,
band-pass filtered between 0.1 and 40 Hz (zero-phase FIR), notch-filtered at 50 Hz, and
re-referenced to the average of all scalp channels. Bad channels were detected via RANSAC
(pyprep 0.4.3) with seed 42 and interpolated. ICA was fit using extended Infomax on a
1 Hz high-pass copy; components classified by ICLabel as eye / muscle / heart / line noise
/ channel noise were rejected (mne-icalabel 0.6.1). Epochs were extracted from –0.2 to
1.2 s, baseline-corrected against –0.2 to 0 s, and trial-level rejection was applied via
AutoReject (autoreject 0.4.3) with random seed 42. Subjects with more than 30% epoch
rejection were excluded; final N=28 of 32 enrolled. Group-level statistics used cluster
permutation (5000 permutations, RNG seed 42, cluster-forming threshold t=2.05, paired t)
in MNE-Python 1.7.1 with channel-time adjacency derived from the standard 10–20 montage.
```

**What no one else does:** no existing pipeline produces submission-ready methods text. People copy-paste from past papers and miss details that reviewers catch.

## D3. Reviewer-anticipation report ✅ DEMONSTRATED

**Pitch:** *"Get rejected by Reviewer 2 before you submit, while you can still fix it."*

> **Status:** Demonstrated on MNE sample case study. 2-round audit loop: Round 1 FAIL (4 critical + 9 major issues), fixed all, Round 2 PASS.

```
> /eeg-audit projects/my-study --reviewer-mode adversarial

# Output: audit-stage/REVIEWER_MEMO.md
# (LLM plays a hostile EEG reviewer)

REVIEWER 2 — Major Concerns

1. CRITICAL: Cluster-forming threshold not justified.
   The submitted analysis uses t=2.05 (corresponding to p<0.05 uncorrected at df=27).
   This is a common but arguable choice. The authors should either justify the
   threshold against a published convention or report TFCE for robustness.

2. MAJOR: Channel adjacency not specified.
   The cluster permutation result on the parietal effect depends on the choice of
   adjacency matrix. The methods say "standard 10–20 montage" but do not specify
   triangulation vs distance-based. Without this, the cluster size cannot be
   verified.

3. MAJOR: Bandpass aggressive for the analyzed time window.
   The 0.1–40 Hz bandpass with the analyzed N1 component (peaking at 150 ms) is
   acceptable, but the lower bound of 0.1 Hz means the filter time-constant is
   ~1.6 s, which leaks into the −200 ms baseline. Consider 0.5 Hz HP or document
   that no measurable distortion exists for this window.

4. MINOR: Subject 14 was excluded post-hoc.
   The exclusion criterion (>30% epoch rejection) was preregistered, but the
   specific subject's exclusion is documented only in FINDINGS.md. Move to methods.

[5 more …]
```

**What no one else does:** post-submission only. Authors find out what Reviewer 2 thinks 6 weeks later.

## D4. Natural-language analysis pivot

**Pitch:** *"Change the contrast in plain English. The pipeline reruns the parts that need to."*

```
> "Add a follow-up analysis: compare valid-cue vs neutral-cue in the same window"

# AEA:
# - reads ANALYSIS_PLAN.md, identifies it's an additive (not destructive) change
# - opens a v2 plan, marks the new claim as exploratory
# - reuses preprocess/ica/epoch/erp from the existing run
# - reruns only stats + figure for the new claim
# - appends to FINDINGS.md without overwriting prior entries
# - flags the new claim as exploratory (not preregistered) in the report
```

**What no one else does:** in MNE-BIDS-Pipeline, you'd edit the YAML and rerun. AEA detects which stages need rerunning and which don't, *and* preserves the audit trail.

## D5. Recipe-citation receipt

**Pitch:** *"When you use a recipe, you get the citation it derives from, so you cite the right paper."*

```
> /eeg-recipe n170-face-inversion --data ...

# At the end of the run:
# This recipe is based on:
#   Rossion, B. et al. (2003). Early lateralization and orientation tuning for face,
#   word, and object processing in the visual cortex. NeuroImage 20:1609–1624.
#   doi:10.1016/j.neuroimage.2003.07.010
#
# BibTeX written to: recipes/n170-face-inversion/citation.bib
# Add to your paper's references.
```

**What no one else does:** existing pipelines don't track method provenance. Authors reinvent and forget to cite the methodological source.

## D7. End-to-end reproducibility receipt ✅ DEMONSTRATED

**Pitch:** *"One file you can email a reviewer that lets them reproduce your analysis exactly."*

> **Status:** Demonstrated in all 3 case studies. REPRO_RECEIPT.md generated with seeds, hashes, versions, and commit SHA.

```
> /eeg-report projects/my-study --include reproducibility-receipt

# Output: report-stage/REPRO_RECEIPT.md
# Contains:
# - All RNG seeds used at every stage
# - Exact backend versions (MNE 1.7.1, autoreject 0.4.3, etc.) from ENVIRONMENT.json
# - Hash of input raw files
# - Hash of every intermediate stage output
# - The recipe (or ANALYSIS_PLAN.md) that drove the run
# - The exact AEA commit SHA used
```

**What no one else does:** even with BIDS, reproducibility receipts at this level are rare and hand-rolled.

## D8. Plan-vs-result divergence detection

**Pitch:** *"AEA notices when your plan changed after you saw the result. It refuses to silently bury that."*

The `eeg-audit` skill checks `ANALYSIS_PLAN.md` mtime against `stats-stage/*.json` mtimes. If a plan revision occurred *after* a result was written, the audit flags it as a critical finding. The user can document the legitimate reason (e.g., reviewer-requested follow-up) or rerun with a frozen plan, but cannot pretend it didn't happen.

**What no one else does:** the closest equivalent is preregistration — but preregistration is a manual, optional process. AEA makes the check automatic.

---

## Demo gates (for releases)

| Version | Required demos | Status |
|---|---|---|
| v0.1 (scaffolding) | — | ✅ Shipped |
| v0.2 (alpha) | D1, D7 | ✅ D1 + D7 demonstrated |
| v0.3 (beta) | D1, D2, D3, D7 | ✅ All four demonstrated |
| v1.0 (public) | All remaining | D4, D6, D8 remaining |

If a demo regresses, the version is held.
