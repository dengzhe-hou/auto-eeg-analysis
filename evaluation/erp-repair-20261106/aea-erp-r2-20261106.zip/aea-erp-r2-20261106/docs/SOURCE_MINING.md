# Source mining — what 3 EEG textbook/course collections add to AEA

Three reference collections were uploaded and mined (read-only) for methods AEA was missing:

| Source | What it is | Size |
|--------|-----------|------|
| `AnalyzingNeuralTimeSeries-main` | Mike X Cohen, *Analyzing Neural Time Series Data* (MIT Press 2014) — MATLAB code | 44 MB |
| `MCKJ0914` | 茗创科技 EEG course (MATLAB/EEGLAB) — the source the resting/complexity recipes were distilled from | 6.3 GB |
| `Python-EEG-Handbook-master` | Chinese Python/MNE handbook (adapts Luck's ERP book + Jia's EEGLAB manual) | 9 MB |

## Headline: AEA already covers ~85% of these sources

Verified against the **live skill bodies**, the following proposed "enrichments" are **already implemented** and were flagged only because the explorer agents didn't read the current skills — treat them as *confirmation that AEA is comprehensive*, not as backlog:

- CSD / surface-Laplacian, ZapLine line-noise, ICLabel → `eeg-preprocess` / `eeg-ica`
- `Epochs.metadata`, `reject_by_annotation` → `eeg-epoch`
- temporal generalization / cross-temporal decoding → `eeg-decoding`
- cluster permutation + FDR + effect sizes → `eeg-stats`
- EMD / mutual information / Shannon / Hilbert-Huang → `eeg-complexity`
- the **entire** phase-connectivity suite (wPLI, wpli2_debiased, PLV, ciPLV, PLI, pli2_unbiased, ppc, coh, imcoh, PSI, Granger + gc_tr, PAC + Rayleigh) → `eeg-connectivity`
- Morlet / multitaper / Stockwell → `eeg-tfr`

## Genuinely new — implemented in this pass

| Skill | Addition | Source (cite the original, not the course) | Value |
|-------|----------|---------------------------------------------|-------|
| `eeg-tfr` | **FWHM-based Morlet** specification (state the time/freq tradeoff as an interpretable full-width-half-maximum in ms/Hz, alongside `n_cycles`) | Cohen (2019) *NeuroImage* 199:81–86 | medium |
| `eeg-stats` | **Brain–behavior correlation** block (Pearson/Spearman + **Fisher-z** for combining/comparing r across subjects/ROIs; robustness checks) | Cohen (2014) Ch 27–28 | medium |
| `eeg-connectivity` | **v-test / gv-test** for phase concentration toward an a-priori angle (the directional complement to the existing Rayleigh test) | Cohen (2014) Ch 26/31 | low |
| `eeg-preprocess` | **REST** (reference at infinity) documented alongside average/mastoid/CSD | Yao (2001) *Physiol Meas* 22:693–711 | low |

## Top recipe opportunity — BUILT (2026-06-20)

**Face perception (N170) on OpenNeuro `ds000117`** (Wakeman & Henson 2015) — the only
non-duplicative public-data ERP recipe across all three sources — has now been **built and
validated**: `recipes/n170-faces/` (face − scrambled N170), validated end-to-end on ds000117
(run-01, N=16): grand-mean N170 = −0.641 µV, t(15) = −2.56, **p = 0.022**, second-level
cluster **p = 0.029**. Downloaded the EEG (embedded in the Elekta MEG `.fif`, ~821 MB/run ×
16) via `openneuro-py`; `tools/validation/validate_n170_faces.py`. Every other source recipe
candidate remains duplicative or blocked on course-private data.

## Blocked — course-private data (method already in AEA)

These paradigms have good demos in MCKJ0914 / the handbook but their bundled data is **non-redistributable course material** (and the method is already covered), so no recipe is buildable from them:

- Resting-state functional connectivity 2-group (MCKJ0914 Part 7) — method = `resting-spectral-connectivity` (validated)
- ERP microstate, ~20 subjects (MCKJ0914 Part 8) — method = `resting-microstate` (validated)
- Resting spectral 2-group, ~58 subjects (MCKJ0914 Part 4) — method = `eeg-spectral`
- Go-NoGo inhibitory control (MCKJ0914 Part 7) — no bundled paper/public data
- Visual working-memory decoding, Bae & Luck 2019 (handbook) — full data not publicly archived
- Theta-gamma PAC (Cohen book) — only a rat recording bundled; PAC already in `eeg-connectivity`

## Copyright boundaries (enforced)

1. **Cohen's book** (MIT Press) — port methods/equations into AEA's own MNE-Python prose; cite Cohen's papers + the original method sources (Vinck 2011, Stam 2007, Lachaux 1999, Morf 1978, Freedman-Diaconis 1981). Never copy MATLAB verbatim.
2. **MCKJ0914** (paid commercial course) — all bundled datasets are course-private/non-redistributable; EEGLAB/FieldTrip code is third-party. Use only as a pointer to public methods; cite primary papers.
3. **Python-EEG-Handbook** (derivative textbook) — re-express methods in original prose citing the upstream papers (Wakeman 2015, Bae 2019, Maris 2007, Widmann 2015, Pion-Tonachini 2019); its demo datasets are Baidu-hosted private subsets even where the upstream (ds000117) is public.

The three source folders are git-ignored (`.gitignore`) and never enter the repo.
