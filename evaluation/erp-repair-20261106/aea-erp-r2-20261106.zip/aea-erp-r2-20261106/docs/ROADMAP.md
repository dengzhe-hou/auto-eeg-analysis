# AEA Roadmap — from scaffolding to "every EEG researcher uses this"

A concrete plan with milestones, demo gates, and adoption tactics. Updated as we go.

## Phase 0 — Scaffolding (✅ shipped 2026-05-10)

- 19 SKILL.md files (16 EEG-specific + eeg-recipe + eeg-methods-text + eeg-pipeline), totalling 6306 lines
- ~38 papers distilled into domain knowledge sections across all skills
- 4 templates (DATASET_BRIEF, ANALYSIS_PLAN, FINDINGS, FIGURE_PLAN)
- Cross-platform env probes (check_env.sh / .ps1)
- MNE-Python backend with LLM-generated code (MNE, Pycrostates, FreeSurfer)
- 4 recipes (N170-face, P300-oddball, alpha-attention, ERN-flankers)
- Manifesto, killer demos, contributing guide

**Exit criterion:** repo is forkable; AGENT_GUIDE.md tells an LLM how to navigate.

## Skill map — the full picture

AEA's value is the breadth and depth of EEG-specific skills. Each skill is a methodology document that the LLM reads to generate and execute analysis code. The map below shows what exists, what's next, and what's planned.

### Core pipeline (Phase 0–1)

| Skill | Status | What it does |
|-------|--------|--------------|
| eeg-preprocess | ✅ tested | filter, re-ref, bad channel, line noise |
| eeg-ica | ✅ tested | ICA + ICLabel auto-labeling |
| eeg-epoch | ✅ tested | event-locked segmentation + AutoReject |
| eeg-erp | ✅ tested | condition averaging, difference waves |
| eeg-stats | 📝 SKILL.md exists | cluster permutation (MNE-Python) |
| eeg-figure | ✅ basic | ERP overlay, topomap, difference wave |
| eeg-methods-text | 📝 SKILL.md exists | auto COBIDAS-MEEG paragraph from logs |
| eeg-audit | 📝 SKILL.md exists | cross-model (GPT via Codex MCP) reviewer |
| eeg-report | 📝 SKILL.md exists | HTML report + reproducibility receipt |
| eeg-bids | 📝 SKILL.md exists | raw → BIDS-EEG conversion |
| eeg-recipe | 📝 SKILL.md exists | run a published recipe end-to-end |
| eeg-pipeline | 📝 SKILL.md exists | top-level orchestrator |
| auto-brief | ✅ tested | auto-generate DATASET_BRIEF from file headers |

### Domain-specific analysis skills (Phase 2–3)

| Skill | Priority | What it does | Why it matters |
|-------|----------|--------------|----------------|
| eeg-tfr | P1 | time-frequency: Morlet wavelets, multitaper, ERDS maps | half of all EEG papers need TFR |
| eeg-spectral | P1 | PSD, FOOOF/specparam aperiodic+periodic decomposition, IAPF | every resting-state study |
| eeg-decoding | P1 | MVPA, temporal generalization, searchlight, cross-decoding | fastest-growing EEG method |
| eeg-behavior | P2 | RT/accuracy analysis, EEG-behavior correlation, single-trial regression | bridges EEG to cognition |
| eeg-connectivity | P2 | wPLI, PLV, coherence, Granger causality, graph metrics | SKILL.md exists, needs flesh |
| eeg-group-compare | P2 | between-group stats (ANOVA, mixed models), effect sizes, forest plots | clinical/developmental EEG |
| eeg-qc | P2 | data quality report: SNR, impedance, channel/epoch rejection rates, signal-to-noise before/after each stage | saves debugging time |
| eeg-eyetracking | P3 | fixation-locked ERP, saccade artifact regression, co-registration | reading/scene perception labs |
| eeg-microstate | P3 | microstate segmentation (ABCD), duration/coverage/occurrence stats | SKILL.md exists, niche |
| eeg-source | P3 | source localization (dSPM, eLORETA, beamformer), ROI time courses | SKILL.md exists, needs FreeSurfer |
| eeg-sleep | P3 | sleep staging, spindle/SO detection, sleep-ERP, NREM/REM contrast | specialized population |
| eeg-emg | P3 | EMG co-recording, cortico-muscular coherence, motor onset | motor paradigm labs |
| eeg-meta-analysis | P4 | cross-recipe result aggregation, mini meta-analysis across datasets | when recipe library is large enough |

### Support skills (Phase 1–2)

| Skill | Priority | What it does |
|-------|----------|--------------|
| eeg-methods-text | P1 | COBIDAS-MEEG paragraph — the "write my methods section" button |
| eeg-audit | P1 | cross-model reviewer — Codex MCP (gpt-6-astra) plays hostile EEG reviewer |
| eeg-figure | P1 | paper-ready figures with consistent style, multi-panel layouts |
| eeg-report | P2 | HTML report (mne.Report wrapper) + REPRO_RECEIPT.md |
| eeg-qc | P2 | quality dashboard before analysis starts |

---

## Phase 1 — End-to-end real run + core differentiators (✅ COMPLETE 2026-05-22)

### 1a. Pipeline works end-to-end (✅ DONE)

- [x] `eeg-preprocess` → `eeg-ica` → `eeg-epoch` → `eeg-erp` on `mne.datasets.sample` (**done 2026-05-22, case study**)
- [x] `auto-brief` generates DATASET_BRIEF from file headers (**done 2026-05-22**)
- [x] `eeg-stats` cluster permutation produces sane output (**done — validated on MNE sample + ERP CORE**)
- [x] `eeg-figure` renders polished paper-ready multi-panel figure (**done — 6-panel figure in ERP CORE full case study**)
- [x] `eeg-recipe` runs a recipe slug end-to-end (**done — ern-flankers recipe, 94.6s from raw to figure**)
- [x] Reproducibility receipt: re-run produces bitwise-identical numerical output (**done**)
- [x] Cross-tool numeric benchmark vs MNE-BIDS-Pipeline, 5 components + both epoching modes: MMN (N=38, CCC 0.9997), P3, N170, response-locked ERN, N400 (all N=14–20) — all within ±0.1 µV/subject, scalar+waveform **CI-gated** (`tools/tests/test_benchmark.py`) (**done 2026-06-24 — [docs/BENCHMARK.md](BENCHMARK.md); 5 of ERP CORE's 7 components; N2pc + LRP remain**)

### 1b. Core differentiators that make AEA worth using (✅ DONE)

- [x] `eeg-methods-text` produces a COBIDAS-MEEG paragraph from pipeline stage logs (**demonstrated in case studies**)
- [x] `eeg-audit` cross-model review via Codex MCP (GPT-5.4): reads ANALYSIS_PLAN + stats output + figures, writes a domain-specific rejection memo (**demonstrated — 2-round audit loop FAIL → PASS on MNE sample**)
- [x] `eeg-audit --reviewer-mode adversarial` works as a pre-submission check (**demonstrated**)

### 1c. First domain-specific analysis skills (✅ DONE)

- [x] `eeg-tfr` — Morlet wavelet TFR + ERDS maps (**verified in ERP CORE theta analysis**)
- [x] `eeg-spectral` — PSD + specparam (FOOOF) aperiodic/periodic decomposition (**SKILL.md complete with domain knowledge**)

### Case study results

Three completed case studies validate the full pipeline:

1. **MNE sample** (auditory N100): full audit loop FAIL → fix 9 issues → PASS
2. **ERP CORE ERN**: single paradigm validation
3. **ERP CORE Full**: 3 claims (N2, ERN, frontal theta), 6-panel figure, 94.6s from raw to publication figure

**Exit criterion:** D1, D2, D3, D7 all work end-to-end. ✅ MET.

## Phase 2 — Skill breadth + killer demos (🎯 target 2026-06 → 2026-08)

Broaden the analysis coverage and implement remaining differentiators.

### 2a. Analysis skills

- [x] `eeg-spectral` — PSD, specparam/FOOOF, IAPF, 1/f slope (**SKILL.md complete with domain knowledge**)
- [x] `eeg-decoding` — MVPA with scikit-learn/MNE-Python: SVM/LDA on sliding windows, temporal generalization matrix, searchlight (**SKILL.md complete with domain knowledge**)
- [x] `eeg-behavior` — RT/accuracy descriptive stats, EEG-behavior single-trial regression (**SKILL.md complete with domain knowledge**)
- [x] `eeg-connectivity` — wPLI, PLV, coherence, Granger, time-resolved, graph + NBS (**SKILL.md complete, smoke-tested**)
- [x] `eeg-group-compare` — between-group cluster permutation, mixed/RM ANOVA, effect sizes, forest plots (**SKILL.md complete 2026-06-19, smoke-tested**)
- [x] `eeg-qc` — automated data-quality dashboard: per-channel SNR/LOF, line-noise, rejection rates, pass/warn/fail gates (**SKILL.md complete 2026-06-19, smoke-tested**)

With these, Phase 2's "6+ analysis skills functional" bar is met (spectral, decoding, behavior, connectivity, complexity, qc, group-compare).

### 2b. Remaining killer demos

- [ ] D4: natural-language plan extension ("add a follow-up contrast")
- [ ] D6: recipe citation receipt (BibTeX auto-emitted)
- [ ] D8: plan-vs-result divergence detection (mtime check)

### 2c. Figure style library

- [ ] Journal-specific figure templates (JNeurosci style, NeuroImage style, Nature Neuro style)
- [ ] Consistent color palettes, font sizes, panel labels across all figure skills
- [ ] Topomap + butterfly + bar plot + violin + temporal generalization matrix templates

**Exit criterion:** all 8 killer demos work. 6+ analysis skills functional. v0.3 beta tag. (3 of 5 analysis skills done; D1/D2/D3/D7 already demonstrated.)

## Phase 3 — Recipe library + specialized skills (🎯 target 2026-08 → 2026-10)

20+ recipes covering the major paradigms. The library effect kicks in at ~10 high-quality recipes.

### 3a. Recipe targets

ERP recipes:
- ✅ N170 face inversion (Rossion 2003)
- ✅ P300 oddball (Polich 2007) — **validated end-to-end on ERP CORE P3, N=20 group, P3b +1.68 µV, cluster p=0.0002** (`recipes/p300-oddball`)
- ✅ Alpha attention cueing (Worden 2000)
- ✅ ERN flankers (Kappenman 2021 / Gehring 1993) — **validated end-to-end (N=1, 94.6s) + N=14 group ERN (error−correct, dz=−1.69, cluster p=0.0004); response-locked cross-tool benchmark CCC 1.000**
- [x] Mismatch negativity (MMN) — Näätänen et al. — **validated end-to-end on ERP CORE MMN, N=38 group, second-level cluster p=0.0002** (`recipes/mmn-oddball`)
- [x] N170 face selectivity (Bentin 1996) — **validated on OpenNeuro ds000117 (N=16, face−scrambled) AND ERP CORE N170 (N=20, face−car, dz=−0.99, cluster p=0.0002)** (`recipes/n170-faces`; ERP CORE run also cross-tool-benchmarked, CCC 1.000)
- [x] N400 semantic priming (Kutas 2011) — **NEW recipe, validated on ERP CORE N400 (N=20, unrelated−related, −2.96 µV, dz=−1.42, cluster p=0.0002); cross-tool benchmark CCC 1.000** (`recipes/n400-semantic`)
- [ ] N400 semantic priming — Kutas & Hillyard
- [ ] N2pc spatial attention — Eimer 1996
- [ ] Lateralized readiness potential (LRP) — Coles 1989

Oscillation/spectral recipes:
- [ ] SSVEP frequency-tagging — Norcia et al.
- [ ] Resting-state IAPF — Klimesch
- [ ] Theta-gamma PAC during working memory — Axmacher 2010
- [ ] Frontal theta during cognitive control — Cavanagh & Frank 2014

Connectivity/advanced recipes:
- [ ] Microstate ABCD — Koenig 2002
- [ ] Phase-locking value — Lachaux 1999
- [ ] Decoding visual category from EEG — Carlson et al. 2013

### 3b. Specialized skills

- [ ] `eeg-eyetracking` — fixation-locked ERP, saccade regression, co-registration
- [ ] `eeg-sleep` — sleep staging, spindle/SO detection, NREM/REM contrast
- [ ] `eeg-source` — flesh out SKILL.md: dSPM, eLORETA, beamformer, ROI extraction
- [ ] `eeg-emg` — cortico-muscular coherence, motor onset detection
- [ ] `eeg-microstate` — flesh out SKILL.md: k-means, GEV, transition probabilities

**Exit criterion:** 15+ accepted recipes, 5 from external contributors. v0.5.

## Phase 4 — Findability + community (🎯 target 2026-10 → 2027-01)

Making it discoverable.

### Demo content
- [ ] **Hero video**: "Reproduce a Nature Neuroscience EEG figure in 5 minutes from raw data" (Twitter, YouTube)
- [ ] **Blog series**: 3 posts on Medium / 知乎 — "Why your EEG methods section is your weakest link", "The recipe pattern", "Why we built a Reviewer 2 simulator"
- [ ] **Conference posters**: OHBM 2026 (June), CCN 2026 (Aug), SfN 2026 (Nov). Bring stickers.

### Awareness channels
- [ ] Submit to: r/neuroscience, MNE / EEGLAB mailing lists, awesome-eeg, awesome-agent-skills (where ARIS is already featured), VoltAgent's awesome-agent-skills
- [ ] Twitter/Mastodon outreach: tag Kay Robbins, Cyril Pernet, Matt Craddock, Dorothée Hoppe, Christian O'Reilly, Robert Oostenveld
- [ ] PaperWeekly feature article (in Chinese; ARIS got featured there twice)
- [ ] Hackathon / workshop at a major EEG conference

### Onboarding ergonomics
- [ ] Standalone CLI ("AEA-Code") mirroring ARIS-Code, so users without Claude Code can still use AEA
- [ ] Docker container with everything pre-installed (for those who hate conda)
- [ ] Web-based recipe browser (read RECIPE.md as rendered HTML, link to validation datasets)

**Exit criterion:** 100+ GitHub stars, 30+ recipes (10 external), 3 papers in the wild that cite an AEA recipe. v1.0.

## Phase 5 — Self-sustaining (🎯 target 2027-Q1 onward)

Once the community contributes faster than we do.

- [ ] Recipe library has 50+ entries
- [ ] Listed in canonical EEG resources (mne.tools "Related projects", EEGLAB plugin index, OHBM resource list)
- [ ] Method papers cite AEA recipes for reproducibility (rather than supplementary code)
- [ ] AEA preprint submitted (target: NeuroImage Methods, eNeuro, or Nature Methods Brief Comms)

## Anti-roadmap (what we WON'T do)

- ❌ Build a GUI. Markdown-only is a feature.
- ❌ Compete with MNE-BIDS-Pipeline on configurability. We win on the recipe + reviewer + methods axes, not config flexibility.
- ❌ Add a database, web service, or daemon. Plain text on disk.
- ❌ Optimize for "newcomer to EEG" — AEA assumes the user knows what their paradigm is. There are better tutorials elsewhere.
- ❌ Real-time / online EEG. Offline only.
- ❌ Drive GUI applications via accessibility tricks.

## Risks and how we'll handle them

| Risk | Likelihood | Mitigation |
|---|---|---|
| Recipes attract low-quality contributions | High | Strict review: citation correct + validation dataset accessible + numerical regression test passes |
| EEG community sees "LLM agent" and bounces | Medium | Lead with the recipe library, not the LLM angle. The LLM is the engine, not the brand |
| MNE team builds something similar | Medium | Welcome it. Differentiate on the recipe + reviewer-anticipation + methods-text axes; offer to contribute upstream |
| Cross-platform support drift | High | Tier the platforms in PLATFORM_SUPPORT.md; CI runs env probe on macOS + Ubuntu + Windows |
| User retention falls because pipeline is "too magical" | Medium | Every stage writes its own log; nothing is hidden; failure modes are explicit |

## Adoption metrics to track

- **Stars + forks**: indicator, not target. (ARIS: ~2k stars in 6 months — that's the bar.)
- **Case studies completed**: 3 (MNE sample, ERP CORE ERN, ERP CORE Full)
- **Recipes accepted**: 4 shipped (the only number that really matters long-term)
- **External recipe authors**: when this exceeds the number of internal contributors, the project is healthy
- **Citations**: when papers cite "we used the AEA `<recipe>` recipe (DOI / commit SHA) for our analysis", we've won

## How to help right now

If you're reading this and want to help:

1. Try the v0.2 alpha when it ships (Phase 1 exit). File an issue if it fails on your data.
2. Pick a paradigm you've published on; contribute a recipe.
3. Help port a published EEG analysis pipeline (PREP, HAPPE) into a recipe so users have a familiar entry point.
4. If you're a tool author (MNE, EEGLAB, Pycrostates, mne-icalabel), tell us where our skill instructions are wrong.
