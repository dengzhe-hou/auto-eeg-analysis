# BIDS-Derivatives output template for ERP results

Write the analysis outputs as a derivative dataset, separate from the read-only raw
tree. The layout below passes the BIDS validator (schema validator 3.0.2, schema 1.2.7)
with no errors. ERP difference waves have no official BIDS suffix yet, so the `_erp`
files are declared in `.bidsignore`, which is how BIDS allows files outside the current
specification.

```
derivatives/<pipeline-name>/
    dataset_description.json     DatasetType "derivative", GeneratedBy, SourceDatasets
    .bidsignore                  lists *_erp.tsv and *_erp.json
    README
    sub-XXX/eeg/sub-XXX_task-<task>_desc-<contrast>_erp.tsv
    sub-XXX/eeg/sub-XXX_task-<task>_desc-<contrast>_erp.json
```

Rules that the validator enforces or that downstream users rely on:

- `dataset_description.json` must exist at the derivative root, with `"DatasetType": "derivative"`.
- `SourceDatasets` records the DOI of the raw dataset (`doi:` prefix) and its version.
  Read the version from the raw dataset's own `CHANGES` file instead of assuming one.
- `<task>` and `<contrast>` are alphanumeric, with no hyphen or underscore inside.
- Column units go in the `_erp.json` sidecar.

`tools/write_erp_derivatives.py` writes this layout:

```python
import sys
sys.path.insert(0, "/workspace/aea/tools")
from write_erp_derivatives import start_derivative, write_subject_erp
root = start_derivative("/workspace/derivatives/erp-analysis", pipeline="my-analysis",
                        source_doi="10.xxxx/xxxxx", source_version="1.0")
write_subject_erp(root, subject="sub-XXX", task="P3", contrast="rareminusfrequent",
                  times_s=times, values_uv=roi_wave)
```

Nothing in this template selects a method. Filter, epoch, ROI and test settings come
from the approved analysis plan.
