# Literature mining — distilling ~280 EEG-analysis papers into AEA

A 12-domain parallel survey (Semantic Scholar / OpenAlex / web) read **276 papers** across
preprocessing, ERP, time-frequency, spectral/aperiodic, connectivity, decoding, microstates,
complexity, source, statistics, resting-state biomarkers, and reproducibility. Each domain
agent read the **live SKILL.md** first and reported only what AEA was genuinely missing.

## Headline: AEA was already comprehensive; ~49 genuinely-new refinements remained

After strict dedup against the actual skill bodies, **49 encodable enrichments** survived
(27 high-value, 20 medium, 2 low) — implemented as original, cited prose in the skills. The
single most valuable findings were **correctness fixes to existing hardcoded defaults**, not
new features:

### Correctness fixes (highest priority — wrong/sub-optimal defaults the survey caught)
- **eeg-ica — live conflict:** ICLabel was trained on **average-referenced, 1–100 Hz** input, but AEA fit ICA on the *pre-reference* montage and passed it straight to ICLabel → silent under-performance. Fix: feed ICLabel an average-referenced copy (keep the substantive re-reference deferred). *(Pion-Tonachini et al. 2019)*
- **eeg-source — outdated physics:** depth weighting and BEM **skull conductivity** (was 1:1/50 brain:skull) updated to McCann et al. 2019 values; `rank='info'` + `plot_evoked_white` whitening QC added. *(Lin 2006; Westner 2022; McCann 2019)*
- **eeg-spectral — specparam fit range:** hardcoded `[1,40]` is fragile; add plateau-capped fit range + `max_n_peaks` guidance, **IRASA** as a second aperiodic estimator, and per-channel **IAPF** (Corcoran 2018 restingIAF) instead of single-channel peak. *(Gerster 2022; Corcoran 2018)*
- **eeg-complexity — DFA on broadband:** DFA/Hurst should run on a **band-limited amplitude envelope** (LRTC), not the z-scored broadband window. *(Hardstone 2012)*
- **eeg-tfr — induced power & baseline units:** prescribe the single-trial-power isolation for *induced* power, warn that divisive dB/logratio baseline is **not** a neutral units choice, and add a **gamma myogenic-artifact** caution. *(Kalcher 1995; Gyurkovics 2021; Yuval-Greenberg 2008)*

### Genuinely-new capabilities added (high-value, by skill)
- **eeg-preprocess:** ASR / Riemannian-ASR transient correction (the gap between interpolate-channel and delete-segment); ZapLine-plus adaptive line-noise; MADE developmental branch. *(Chang 2018; Blum 2019; Klug 2022; Debnath 2020)*
- **eeg-ica:** wavelet-enhanced ICA (wICA) partial cleaning (preserves leaked neural signal). *(Castellanos & Makarov 2006)*
- **eeg-erp:** jackknife latency scoring, regression-ERP (rERP) overlap deconvolution, Standardized Measurement Error (SME). *(Kiesel 2008; Smith & Kutas 2015; Ehinger & Dimigen 2019; Luck 2021)*
- **eeg-stats / eeg-group-compare:** Cluster-Depth Test (the *remedy* for cluster-extent mis-localization), lmeEEG crossed subject×item mass-univariate, TOST equivalence + a-priori power. *(Frossard & Renaud 2022; Visalli 2024; Lakens 2018; Boudewyn 2018)*
- **eeg-connectivity:** leakage-corrected AEC-c, OMST + NBS-TFCE thresholding, benchmarked source-space FC aggregation. *(Hipp 2012; Dimitriadis 2017; Pellegrini 2023)*
- **eeg-decoding:** Riemannian tangent-space + Euclidean Alignment, block-design temporal-proximity leakage warning, the Haufe transform ("never read decoder weights as brain activity"). *(Barachant 2012; He & Wu 2020; Li 2021; Haufe 2014)*
- **eeg-complexity:** the perturbational complexity index family (PCI/PCIst), multiscale entropy (MSE/RCMSE), multichannel spatiotemporal LZc/ACE/SCE, neuronal-avalanche criticality. *(Casali 2013; Comolatti 2019; Costa 2002; Schartner 2015; Shriki 2013)*
- **eeg-microstate / eeg-spectral / eeg-report / eeg-bids / eeg-pipeline:** AAHC alternative, multi-site ComBat harmonization, multiverse/specification-curve reporting, PyLossless non-destructive intermediates, etc.

## New recipe candidates (all with PUBLIC data) — a Phase-3 roadmap

| Paradigm | Public dataset | Exercises |
|---|---|---|
| ERP CORE data-quality + reliability (SME, G-theory, min-trials D-study) | ERP CORE (N=40, 7 components) | SME, lmeEEG |
| Propofol consciousness/complexity battery | OpenNeuro ds005620 (or Chennu 2016) | MSE/RCMSE, multichannel-LZc, avalanches, DFA |
| Resting aperiodic biomarker + ComBat + age-normative | TDBRAIN (N=1274); LEMON ds000221 | specparam fit-range, IRASA, harmonization |
| Cross-subject motor-imagery decoding (Riemannian + EA) | BCI IV-2a (MOABB); eegmmidb | tangent-space, Euclidean Alignment, subject-CV |
| Source-space FC benchmark (EO/EC alpha; AD/FTD contrast) | ds005385 (Dortmund); ds004504 | AEC-c, OMST, NBS-TFCE |
| ERP preprocessing multiverse / specification-curve | ERP CORE; EEGManyPipelines | multiverse panel, HPF guard |
| Individual-MRI source N170 → fusiform | ds000117 (T1+EEG) | depth/rank/whitening/conductivity fixes |
| Mobile/gait EEG cleaning | OpenNeuro ds001971 (108-ch + EMG) | ASR/rASR, ICLabel-spec fix |

## Honesty & copyright
- Most of the field's standard toolkit was **already in AEA** (verified against the SKILL.md files, not assumed) — the survey's main value is the ~49 refinements above plus this roadmap.
- All papers are real (Semantic Scholar / OpenAlex verified); methods are re-expressed in AEA's own prose citing the **original** papers. No copyrighted text was copied.
