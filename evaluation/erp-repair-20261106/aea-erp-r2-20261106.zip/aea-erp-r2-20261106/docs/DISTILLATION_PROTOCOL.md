# Distillation protocol (hardened)

How new methods enter AEA's skills. The first two mining passes (`SOURCE_MINING.md`,
`LITERATURE_MINING.md`) were method-coverage surveys — they asked *"what is AEA missing?"* and did it
well (~85% coverage confirmed, ~49 cited refinements). But they had a **structural blind spot**: they
never asked *"what systems did others build?"*, so competitors (e.g. EEGAgent, whose PDF was literally
in `papers/`) never reached the competitor matrix. This protocol closes that, and makes the distilled
citations verifiable rather than trusted.

## Every mining pass MUST run these phases, in order

### Phase 0 — Prior-work / competitor scan (NEW; the fix)
Before surveying methods, search **what others have *built*** (not just what AEA lacks):
- Query the LLM×EEG / agentic-EEG / EEG-skills space (arXiv + Semantic Scholar + web); tag each hit by
  **artifact type** (agent framework vs skills corpus vs classical pipeline).
- For each system, check the four AEA differentiators (numeric validation / cross-model audit / COBIDAS
  methods / recipe reproducibility) and record ✗/✓.
- **Update `docs/RELATED_WORK.md` and any affected novelty claim in `COMPARISON.md` (N1–N5).** If a
  competitor ships a feature AEA claimed, revise the claim — do not quietly keep it.

### Phase 1 — Method survey (existing)
Multi-domain parallel survey. Each domain agent **reads the live `SKILL.md` first** and reports only
genuine gaps. Keep this — it is why dedup works.

### Phase 2 — PRISMA-style screening log (NEW)
Do not just report survivors. Record, per domain, a short ledger:
`screened N → excluded M (reasons: already-in-skill / duplicate / off-scope / low-quality) → K encodable`.
Commit the ledger alongside the mining doc so the selection is auditable, not a black box.

### Phase 3 — Encode as original, cited prose (existing)
Re-express methods in AEA's own words citing the **original** papers. Never copy source text/code.

### Phase 4 — Citation audit (NEW; makes distillation verifiable, not trusted)
Every newly-added citation must be verified real + correctly attributed via the
DBLP → CrossRef → `[VERIFY]` chain (the `citation-audit` skill). No BibTeX from memory.

## First citation audit (2026-07) — spot-check of the highest-load "genuinely-new" citations

| Citation (skill) | Claim it supports | Verified? |
|---|---|---|
| **McCann et al. 2019**, *Brain Topography* (eeg-source) | skull conductivity ≈ **0.02 S/m** (was 1:1/50) | ✅ real, value correct |
| **Hipp et al. 2012**, *Nat. Neurosci.* (eeg-connectivity) | orthogonalized amplitude-envelope correlation (leakage-corrected AEC) | ✅ real, correct |
| **Pion-Tonachini et al. 2019**, *NeuroImage 198* (eeg-ica) | ICLabel automated IC classifier | ✅ real, correct |

3/3 verified real, correctly attributed, values correct — the distilled corrections are grounded, not
hallucinated. A full pass over all ~85 inline citations is the next step (`/citation-audit` over `skills/`).

## Not adopted (with reasons)
- **Auto skill-induction from execution traces** (Voyager-style): blocked — requires real user trajectories,
  and external adoption is currently 0. Revisit once traces exist.
- **`meta-optimize`** (outer-loop self-improvement, inspired by Meta-Harness, Lee et al. 2026): the right
  home for "SOTA self-improvement" — run it on accumulated usage logs to optimize `SKILL.md` / reviewer
  prompts once there is usage to learn from.
