"""Structural self-check of ERP outputs; it holds no reference values.

Usage: python tools/check_erp_outputs.py --plan /workspace/PUBLIC_CONTRACT.json --workspace /workspace
Passing means the required fields and files are present and consistent, not that the
numbers are right. Writes SELF_CHECK.json in the workspace.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np


def check_outputs(plan, workspace):
    workspace = Path(workspace)
    problems = []
    path = workspace / "result.json"
    result = {}
    if path.is_file():
        result = json.loads(path.read_text())
    else:
        problems.append("result.json is missing")
    for key in plan["required_results"]:
        if key not in result:
            problems.append(f"result.json lacks {key}")
    evidence = workspace / "analysis_evidence.npz"
    if not evidence.is_file():
        problems.append("analysis_evidence.npz is missing")
    else:
        with np.load(evidence, allow_pickle=False) as data:
            for key in plan["required_evidence"]:
                if key not in data:
                    problems.append(f"analysis_evidence.npz lacks {key}")
    root = workspace / plan["derivatives"]["root"]
    description = root / "dataset_description.json"
    if not description.is_file():
        problems.append("derivative dataset_description.json is missing")
    else:
        value = json.loads(description.read_text())
        if value.get("DatasetType") != "derivative":
            problems.append('derivative DatasetType must be "derivative"')
        if not value.get("SourceDatasets"):
            problems.append("derivative SourceDatasets is missing")
    for subject in result.get("subjects_included", [result.get("subject")]):
        if subject and not list((root / subject).rglob("*")):
            problems.append(f"no derivative files for {subject}")
    return {"passed": not problems, "problems": problems,
            "scope": "Structure only. External numerical verification remains separate."}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", required=True, type=Path)
    parser.add_argument("--workspace", required=True, type=Path)
    args = parser.parse_args()
    report = check_outputs(json.loads(args.plan.read_text()), args.workspace)
    (args.workspace / "SELF_CHECK.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
