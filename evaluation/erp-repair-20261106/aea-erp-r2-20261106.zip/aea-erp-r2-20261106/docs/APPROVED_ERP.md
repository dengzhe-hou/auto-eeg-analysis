# Execute an approved ERP plan

This route supports the explicit public ERP plan schema with `request_kind`,
`dataset`, `analysis`, `derivatives`, `required_results` and `required_evidence`.
An approved plan supplies processing order, conditions, epoch/baseline, ROI,
window, eligibility and any group tests. This route introduces no new defaults.

Prepare a task-matching resource packet from the checkout root:

```bash
python tools/prepare_erp_packet.py --plan projects/my-study/APPROVED_PLAN.json --output projects/my-study/ERP_PACKET.md --receipt projects/my-study/ERP_PACKET_RECEIPT.json
```

Single-subject packets contain the approved execution section and callable
helpers. Group packets add the participant-level group procedure. ERP CORE's
error-minus-correct contrast adds its documented response decoder. Whole general
manuals and unrelated recipe contrasts are not included. The receipt records
the actual selected sections and files. No private reference outputs are read.
This is a new resource configuration, not a modification of an old frozen run.

The source functions in `skills/eeg-epoch/scripts/erp.py` can also be used from a
saved analysis script:

```python
from pathlib import Path
import sys
sys.path.insert(0, str(Path(aea_checkout) / 'skills/eeg-epoch/scripts'))
from erp import mean_roi_amplitude, save_erp_outputs
from erp_core_events import erp_core_ern_events

# Only for ERP CORE's documented ERN error-minus-correct response mapping.
# rows are read from that recording's events.tsv. raw has been processed to the
# approved output rate. The sidecar is retained with the analysis provenance.
events, mapping_record = erp_core_ern_events(
    rows, sfreq=raw.info['sfreq'], first_samp=raw.first_samp, n_times=raw.n_times)

# Create epochs from events with the actual approved MNE Epochs arguments.
# Pass that existing Epochs object, its condition names and approved choices.
measured = mean_roi_amplitude(epochs, plus=plus_condition, minus=minus_condition,
                              roi=approved_roi, window_s=approved_window_s)
result.update({k: measured[k] for k in
               ['roi_amplitude_uv', 'n_trials_plus', 'n_trials_minus']})
evidence = {k: measured[k] for k in
            ['times_s', 'roi_difference_uv', 'amplitude_unit', 'sfreq_hz']}
save_erp_outputs(new_run_directory, result=result, evidence=evidence)
```

The snippet uses study variables from your saved script. It does not create an
analysis plan or apply preprocessing. Use the approved condition mapping and
trial threshold; the event decoder is not a general rule for every dataset.

The measurement helper reports missing ROI channels with the actual available
names and rejects non-EEG ROI types before interpreting values as EEG uV. It
uses the explicitly requested ROI channels, including a channel still marked
bad when the approved ROI includes it. Resolve exclusion in the approved plan;
the helper does not silently remove or interpolate it. A measurement window
extending outside the actual epoch is rejected instead of shortened. Normal
rounding of nominal epoch bounds by up to half a sample remains allowed. These
checks do not add preprocessing or change the requested ROI or window.

After writing actual derivative files, run the public self-check from the same
checkout. Supply an explicit tolerance for **internal arithmetic agreement**:

```bash
python tools/check_erp_outputs.py --plan projects/my-study/APPROVED_PLAN.json --workspace projects/my-study/new-run --atol-uv 1e-9
```

The example tolerance permits floating-point rounding when comparing a saved
mean with its own evidence arrays. It is not a scientific acceptance tolerance
against reference EEG results. Choose the internal precision for the actual
serialization used and record it. A failed check returns a nonzero exit status,
writes SELF_CHECK.json and leaves computed artifacts untouched. A revised run
uses a new directory. Without `--atol-uv`, the coverage reports arithmetic as
not run. Unavailable external checks are also recorded as not run.

The arithmetic check requires `amplitude_unit='uV'` and the actual `sfreq_hz`
in the evidence. It checks the MNE integer-sample epoch grid, waveform shape,
finite values and result means. Group evidence additionally aligns participant
identities, their amplitudes, and the group mean. A unit declaration alone
cannot prove that raw V were converted correctly: both a wrong result and a
consistently scaled wrong waveform can agree internally. This tool does not
verify raw data, event classification, group tests or BIDS conformance.

For already approved execution, read available sidecars and repair programming
errors without stopping for renewed approval. Keep independent approved work
moving when a genuinely missing scientific choice blocks one step. Save actual
computed artifacts before further diagnostics and preserve failed checks. A
missing variable is not evidence of kernel-state loss. Follow the researcher's
decision boundary for scientific changes, model settings and new experiments.
