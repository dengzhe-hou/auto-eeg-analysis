## Constants

- **CHECKLIST = `COBIDAS-MEEG`** (Pernet et al. 2020, "Issues and recommendations from the OHBM COBIDAS MEEG committee for reproducible EEG and MEG research").
- **VENUE_DEFAULT = `generic`** — paragraph adapts to venue style (NeurIPS more terse, JNeurosci more detailed, etc.).
- **OUTPUT_MD = `report-stage/methods.md`**.
- **OUTPUT_TEX = `report-stage/methods.tex`** (LaTeX-ready).
- **OUTPUT_BIB = `report-stage/methods_references.bib`** (auto-collected BibTeX).
- **OUTPUT_ARTEMIS = `report-stage/methods_artemis.json`** (machine-readable structured methods, ARTEM-IS schema).
- **OUTPUT_DEVIATIONS = `report-stage/preregistration_deviations.md`** (executed-vs-planned diff).

## What goes into the paragraph

The COBIDAS-MEEG checklist's required EEG reporting items, gathered from the project's own logs (no manual input needed):

### Sample (from DATASET_BRIEF.md + the executed stages' cohort/exclusion records)
- N enrolled, N analyzed, N excluded with reasons.
- Demographics (age, handedness, sex if reported).

### Acquisition (from DATASET_BRIEF.md)
- System, channel count + montage, online filter, sampling rate, online reference.

### Preprocessing (from preprocess-stage/preprocess_summary.json + BACKEND_RESOLUTION.md)
- Backend + actual recorded version; do not fill an unrecorded version from this template.
- Bandpass (l_freq, h_freq, filter type, zero-phase y/n).
- Notch frequencies.
- Resample (if applied).
- Reference scheme.
- Bad-channel detection rule + tool version + seed.
- Bad channels per subject (mean, range).

### ICA (from ica-stage/ica_summary.json)
- Method (extended Infomax, etc.), n_components, seed.
- Pre-fit HP filter cutoff (best-practice 1 Hz copy).
- Auto-labeling tool + version (mne-icalabel 0.6).
- Component classes rejected, mean count per subject.
- Subjects with manual review.

### Epoching (from epoch-stage)
- Window, baseline, AR mode, AR tool version, seed.
- Min trials per condition rule and subjects excluded.

### Statistics (from stats-stage/*_cluster_perm.json + ANALYSIS_PLAN.md)
- Per claim: contrast, channels/ROI, time/freq window, test, n_permutations, RNG seed, cluster-forming threshold, adjacency definition, alpha.
- Multiple-comparisons strategy across claims.
- Effect-size metric (Cohen's dz / partial eta²).

### Source analysis (from source-stage/source_summary.json, if a source-localization stage ran)
- Head/forward model: BEM (n layers) or template (fsaverage), conductivities, and how the source space was built (surface oct6 / volumetric grid spacing).
- Inverse method (dSPM / sLORETA / eLORETA / MNE / LCMV beamformer) and the regularization actually used: `lambda2 = 1 / SNR**2` (state the assumed SNR, default SNR=3 → lambda2≈0.111) for minimum-norm methods, or the noise-covariance regularization for beamformers.
- Noise-covariance and (for beamformers) data-covariance estimation windows, the estimator, and rank handling.
- Whether individual source estimates were morphed to a common template (fsaverage) before group statistics / display.
- Atlas used to name peaks/clusters (Desikan-Killiany or Destrieux via `read_labels_from_annot`, or AAL for volumetric STCs) and the reported coordinate system (MNI).

### Reporting standard
- Cluster-level p, t_obs sum, channels involved, time window, peak channel/time, effect size.

## Phases

### A. Gather

Read `DATASET_BRIEF.md`, the approved `ANALYSIS_PLAN.md` and the saved
`ENVIRONMENT.json`. Obtain planned stages and their actual required source paths
from the approved plan/execution ledger. Do not require event epochs or cluster
files for a continuous descriptive analysis, or ICA for a route that did not
plan it. Do not create these stages just to fill a reporting template.

```python
# AEA example: methods-stage-inputs
import runpy
from pathlib import Path
input_helpers = runpy.run_path(str(Path(AEA_ROOT) / 'skills/eeg-report/scripts/inputs.py'))
for core in ('DATASET_BRIEF.md', 'ANALYSIS_PLAN.md', 'ENVIRONMENT.json'):
    if not (Path(run_dir) / core).is_file():
        raise ValueError(f'Required methods provenance is unavailable: {core}')
stage_inventory = input_helpers['collect_stage_inputs'](
    run_dir, planned_stages=approved_reporting_stages,
    required_sources=recorded_required_stage_sources)
input_helpers['require_planned_inputs'](stage_inventory)
```

`recorded_required_stage_sources` maps each planned stage to its actual saved
relative file paths/patterns, including backend/settings and checks when required.
Use source-stage/SOURCE_PARAMS.json, participant subdirectories or other real
files when those are the actual outputs; do not invent a summary file to satisfy
a fixed name. Available files still need their actual configuration/execution
records inspected before prose is written. A missing planned source blocks a
completed methods paragraph and names the required file/stage. Preserve a draft
with the gap recorded; continue independent work without fabricating values.

### B. COBIDAS checklist auto-audit

Before composing the paragraph, run through the full COBIDAS-MEEG checklist and flag any items that cannot be filled from the gathered data. This catches gaps BEFORE output rather than after.

**COBIDAS-MEEG Required Items Checklist**:

| # | Item | Source file | Status |
|---|------|------------|--------|
| 1 | Sample size (enrolled, analyzed, excluded) | DATASET_BRIEF + epoch exclusion | |
| 2 | Demographics (age, sex, handedness) | DATASET_BRIEF | |
| 3 | Acquisition system + model | DATASET_BRIEF | |
| 4 | Channel count + montage name | DATASET_BRIEF | |
| 5 | Online reference | DATASET_BRIEF | |
| 6 | Online filter settings | DATASET_BRIEF | |
| 7 | Sampling rate | DATASET_BRIEF | |
| 8 | Offline bandpass (type, cutoffs, zero-phase) | preprocess_summary | |
| 9 | Notch filter (frequencies) | preprocess_summary | |
| 10 | Re-reference scheme | preprocess_summary | |
| 11 | Bad-channel method + tool version | preprocess_summary | |
| 12 | Bad-channel stats (mean, range) | preprocess_summary | |
| 13 | ICA method + n_components + seed | ica_summary | |
| 14 | ICA pre-fit HP cutoff | ica_summary | |
| 15 | Auto-label tool + version | ica_summary | |
| 16 | Rejected component classes + mean count | ica_summary | |
| 17 | Epoch window + baseline | epoch_summary | |
| 18 | Artifact rejection method + tool version | epoch_summary | |
| 19 | Min trial rule + exclusions | epoch_summary | |
| 20 | Statistical test + implementation | stats JSON | |
| 21 | N permutations + seed | stats JSON | |
| 22 | Cluster-forming threshold derivation | stats JSON | |
| 23 | Adjacency definition | stats JSON | |
| 24 | Alpha + MC correction | stats JSON | |
| 25 | Effect size metric + formula | stats JSON | |
| 26 | Tail + justification | stats JSON | |
| 27 | Source head/forward model (BEM or template) | source_summary | |
| 28 | Inverse method + lambda2/SNR or beamformer reg | source_summary | |
| 29 | Noise (and data) covariance windows | source_summary | |
| 30 | Morph-to-fsaverage before group/display | source_summary | |
| 31 | Atlas for labeling + coordinate system (MNI) | source_summary | |

Checklist items are conditional on the approved analysis. Event/trial rows are
not_applicable for a continuous route; ICA/source/inference rows are
not_applicable when those stages were not planned. Inference rows must match the
actual approved test, which need not be a cluster permutation. Continuous methods
report retained duration, segmentation, participants and the actual analysis
parameters instead of trial counts or significance invented for the checklist.

For each applicable item:
- `filled`: value read from the corresponding actual source record.
- `missing`: an applicable source exists but the field was not recorded; warn,
  state not recorded, and never fill it from an example.
- `unavailable`: a planned required source is absent; name it and block a
  completed methods output until the dependent stage/input is resolved.
- `not_applicable`: the approved workflow does not include that method; do not
  mark it failed or create a new scientific analysis to satisfy the template.

Source-specific rows use the same shared stage inventory. Preserve failed runs
and exclusions; a directory/file merely existing does not prove method execution.

### C. Resolve venue style

Each venue has specific word count targets and style expectations:

| Venue | Target words | Style notes |
|---|---|---|
| `NeurIPS` | ~200 | Terse. Defer preprocessing details to supplementary. Focus on statistical approach. No subheadings in methods. |
| `ICML` / `ICLR` | ~200 | Similar to NeurIPS. Emphasize reproducibility via code/data availability statement. |
| `JNeurosci` | ~500 | Full detail required. Reviewers expect every COBIDAS item. Subheadings encouraged. |
| `NeuroImage` | ~400 | Moderate detail. COBIDAS compliance expected. Include software versions inline. |
| `Cerebral Cortex` | ~400 | Similar to NeuroImage. Emphasize effect sizes and power considerations. |
| `FrontiersHumanNeuro` | ~400 | Standard with reproducibility emphasis. Include data/code availability. |
| `generic` | ~300–400 | Paragraph form, covers all COBIDAS items. Default when no venue specified. |

When venue is `NeurIPS` or `ICML`/`ICLR`:
- Main methods: acquisition system, key preprocessing steps (1 sentence), statistical test + parameters.
- Generate a separate `report-stage/methods_supplementary.md` with full COBIDAS detail for appendix.

### D. Compose

Build the paragraph by template-interpolating values into the COBIDAS structure:

1. **Markdown output** (`report-stage/methods.md`):
   - Structured prose following venue style.
   - All numerical values interpolated from stage JSONs.
   - Verify every `<placeholder>` is resolved before outputting; if any unresolved, abort.

2. **LaTeX output** (`report-stage/methods.tex`):
   - Proper LaTeX formatting: `\textit{}` for software names, `\SI{}{}` for units (if siunitx available).
   - Citation commands using `\citep{}` / `\citet{}` with keys from BibTeX file.
   - Escape special characters (`%`, `&`, `_`, `#`, `$`).
   - Wrap in `\subsection{EEG Recording and Analysis}` or appropriate venue section command.
   - Example:
     ```latex
     \subsection{EEG Recording and Analysis}
     EEG was recorded from \num{64} Ag/AgCl electrodes arranged in the
     international 10--20 system (actiCHamp Plus, Brain Products GmbH)
     at a sampling rate of \SI{512}{\hertz}, referenced online to FCz.
     ...
     ```

3. **Machine-readable ARTEM-IS artifact** (`report-stage/methods_artemis.json`):
   - Every field already harvested for the COBIDAS prose (montage, online/offline filters, epoch window, baseline, ICA settings, component-measurement window, stats parameters) is also serialized into an ARTEM-IS-shaped JSON. The COBIDAS paragraph is a human-readable prose checklist; the ARTEM-IS JSON is the complementary structured schema that makes a reported methods section cross-study searchable and machine-diffable. Emit both from the same interpolation pass so the prose and JSON never drift apart.
   - Cite: Šoškić et al. (2025), Psychophysiology e70187 (ARTEM-IS structured EEG-methods schema).

4. **Preregistration-deviation section** (`report-stage/preregistration_deviations.md`):
   - Because AEA freezes and timestamps `ANALYSIS_PLAN.md`, that file functions as a de-facto preregistration. Diff the executed analysis (the stage `*_summary.json` values actually used) against the frozen plan and enumerate every decision that is NOT in the plan — an added covariate, a changed time/ROI window, an extra exclusion criterion, a swapped test. Label each such decision exploratory/post-hoc in the output. Hand-written methods sections systematically omit these silent departures; surfacing them is what keeps the confirmatory/exploratory line honest.
   - Cite: Paul, Govaart & Schettino (2021), Int. J. Psychophysiol. 164:52 (reporting preregistration deviations).

5. **Source-analysis sentence template** (emit only if a source-stage ran):
   > "Cortical sources were estimated using {{method}} with the inverse operator regularized at lambda2 = 1/SNR^2 (assumed SNR = {{snr}}; lambda2 = {{lambda2}}). The forward model used a {{n_layer}}-layer BEM (conductivities {{cond}}) / the fsaverage template, with the noise covariance estimated from the {{noise_cov_window}} interval. Individual source estimates were morphed to fsaverage before group analysis. Peaks were labeled using the {{atlas}} atlas and are reported in MNI coordinates."
   For an LCMV beamformer, replace the lambda2 clause with the data-covariance window and the covariance regularization (e.g. `reg=0.05`).

6. **ERP group-statistics sentence template** — state which of the two routes was used so the paragraph is internally consistent with the stats stage:
   - Hypothesis-driven (a-priori ROI + window): "Mean amplitude was averaged over {{roi_channels}} in the {{tmin}}-{{tmax}} ms window (or peak latency/amplitude extracted with `Evoked.get_peak(mode='{{mode}}', tmin, tmax)`) per participant and entered into a single {{test}}; no mass-univariate correction was required."
   - Data-driven 'when'/'where': defer to the cluster-permutation sentence already emitted from the stats stage, and say the time window/channel set was determined data-drivenly rather than pre-specified (so cluster boundaries are NOT interpreted as effect onset/offset — see Sassenhagen & Draschkow 2019).
   Prefer reporting **mean amplitude** over peak amplitude for noise robustness, and state that the window was pre-registered when the route is hypothesis-driven.

### E. Automatic BibTeX collection

Scan all stage `BACKEND_RESOLUTION.md` files and the tools used. Collect BibTeX entries for every software and method referenced:

**Core entries to always include**:
- MNE-Python: Gramfort et al. (2013), Frontiers in Neuroscience
- COBIDAS-MEEG: Pernet et al. (2020), Nature Neuroscience

**Conditional entries** (include only if used):
- autoreject: Jas et al. (2017), NeuroImage
- mne-icalabel: Li et al. (2022), Journal of Open Source Software
- MNE-BIDS: Appelhoff et al. (2019), JOSS
- ICLabel: Pion-Tonachini et al. (2019), NeuroImage
- LIMO EEG: Pernet et al. (2011), Computational Intelligence and Neuroscience
- Cluster permutation methodology: Maris & Oostenveld (2007), Journal of Neuroscience Methods
- FDR control: Benjamini & Hochberg (1995), JRSS-B; Genovese et al. (2002), NeuroImage (cite when `mne.stats.fdr_correction` was used).
- SciPy (cluster-forming threshold via `scipy.stats.t.ppf` / `f.ppf`): Virtanen et al. (2020), Nature Methods.
- Source localization: Hämäläinen & Ilmoniemi (1994), Med Biol Eng Comput (MNE); Dale et al. (2000), Neuron (dSPM); Van Veen et al. (1997), IEEE TBME (LCMV beamformer) — include only the one(s) matching the inverse method in source_summary.
- Atlas for source labeling: Desikan et al. (2006), NeuroImage (Desikan-Killiany) or Tzourio-Mazoyer et al. (2002), NeuroImage (AAL).
- ERP technique reference: Luck (2014), An Introduction to the ERP Technique, MIT Press; Chaumon et al. (2015), J Neurosci Methods (ICA artifact handling).
- Microstates: Koenig et al. (2002) / Michel & Koenig (2018), NeuroImage (cite when a microstate stage ran).
- Structured machine-readable methods: Šoškić et al. (2025), Psychophysiology e70187 (ARTEM-IS) — include when the ARTEM-IS JSON is emitted.
- Preregistration-deviation reporting: Paul, Govaart & Schettino (2021), Int. J. Psychophysiol. 164:52 — include when a deviation section is emitted.

Write collected entries to `report-stage/methods_references.bib`.

If running on a recipe, also include the recipe's own `citation.bib` entries.

### F. Output + self-check

Write output files, then append the COBIDAS self-check:

```markdown
# COBIDAS-MEEG self-check

filled  Sample size + exclusions reported
filled  Acquisition system + montage + online filter + reference declared
filled  Preprocessing: bandpass, notch, resample, re-reference, bad-channel rule
filled  ICA: method, n_components, seed, auto-label tool, rejected classes
filled  Epoching: window, baseline, AR tool, seed, min-trial rule
filled  Statistics per claim: contrast, channels, window, test, perms, seed, threshold, adjacency, MC strategy
filled  Reporting standard: cluster p, t_obs, channels, time, effect size
warning Issue: <if any check could not be filled from logs, list here>
```

Use `filled` / `missing` / `unavailable` / `not_applicable` status markers (no emoji — plain text labels).

### G. Cross-reference suggestions

- Suggest BibTeX entries to cite for each method (mne-python, autoreject, mne-icalabel, COBIDAS guideline).
- If running on a recipe, append the recipe's reference papers to suggest citations.
- Print a "Suggested citations" summary to the user listing what to cite and why.

## Failure modes

| Symptom | Action |
|---|---|
| Planned stage source missing | Name the actual missing file/pattern and keep completed methods blocked; an unplanned stage is not_applicable. |
| `ANALYSIS_PLAN.md` empty | Stop and resolve the approved analysis plan; a descriptive plan does not require inventing a statistical contrast. |
| Backend version unknown | Re-run env probe; if still unknown, note "version not recorded" in the paragraph and the self-check warns. |
| Venue not recognized | Default to `generic`. Warn user. |
| LaTeX compilation fails | Output `.tex` anyway; note that user may need to adjust packages (siunitx, etc.). |
| BibTeX key collision | Append suffix (`_a`, `_b`) to disambiguate. |
| Source analysis planned but required recorded source inputs absent | Source rows are unavailable; name the actual missing paths from the execution ledger. |
| Cluster-forming threshold reported in stats JSON as a bare number with no df/alpha | Recompute the intended threshold note as `t = scipy.stats.t.ppf(1-alpha/2, df)`; if df is unknown, write "cluster-forming threshold = MNE default (threshold=None)" and warn. |
| Stats JSON reports a p-value but no multiple-comparison method | Do NOT write "significant". Emit "uncorrected" with a self-check warning, and refuse to label it significant. |
| Trial counts per condition absent from epoch_summary | Report rejection percentage only, flag retained-trials as `missing`, and warn that SNR cannot be assessed. |
| Group n < ~12 for a between/within-subject test | Proceed but add an "underpowered (n < 12)" warning to the self-check. |
